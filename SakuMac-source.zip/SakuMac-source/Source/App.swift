import SwiftUI
import AppKit
import UniformTypeIdentifiers

@main struct SakuApp: App {
    @StateObject var store = Store(); @StateObject var lock = Lock(); @StateObject var drive = GoogleDrive()
    var body: some Scene {
        WindowGroup("SakuMac") { RootView().environmentObject(store).environmentObject(lock).environmentObject(drive).frame(minWidth: 1050, minHeight: 700) }
            .windowStyle(.titleBar).defaultSize(width: 1220, height: 800)
            .commands { CommandGroup(replacing: .newItem) {} }
    }
}
func openFile(_ types: [UTType], action: (URL) throws -> Void) throws { let p = NSOpenPanel(); p.allowedContentTypes = types; p.canChooseDirectories = false; p.allowsMultipleSelection = false; if p.runModal() == .OK, let u = p.url { try action(u) } }
func saveFile(_ name: String, type: UTType, data: Data) throws { let p = NSSavePanel(); p.nameFieldStringValue = name; p.allowedContentTypes = [type]; if p.runModal() == .OK, let u = p.url { try data.write(to: u, options: .atomic) } }
let accent = Color(red: 0.10, green: 0.52, blue: 0.40)
struct RootView: View {
    @EnvironmentObject var store: Store; @EnvironmentObject var lock: Lock; @EnvironmentObject var drive: GoogleDrive
    @Environment(\.scenePhase) var scenePhase
    @State<String> var section = "Ringkasan"; @State<Bool> var newEntry = false; @State<Entry?> var editEntry: Entry?
    @AppStorage("appearance") var appearance = "Sistem"
    let sections = [("Ringkasan", "square.grid.2x2"), ("Transaksi", "list.bullet.rectangle"), ("Dompet", "wallet.bifold"), ("Kategori", "tag"), ("Utang & piutang", "person.2"), ("Laporan", "chart.bar.xaxis"), ("Backup & pengaturan", "gearshape")]
    var body: some View {
        Group {
            if lock.locked { LockView() }
            else {
                NavigationSplitView {
                    VStack(alignment: .leading, spacing: 20) {
                        HStack { Image(systemName: "leaf.circle.fill").font(.system(size: 35)).foregroundStyle(accent); VStack(alignment: .leading) { Text("SakuMac").font(.title2.bold()); Text("Catatan keuangan pribadi").font(.caption).foregroundStyle(.secondary) } }.padding(.top, 20)
                        List(selection: $section) { ForEach(sections, id: \.0) { item in Label(item.0, systemImage: item.1).tag(item.0).padding(.vertical, 5) } }.listStyle(.sidebar)
                        VStack(alignment: .leading, spacing: 6) { Label("Tersimpan di Mac ini", systemImage: "externaldrive.badge.checkmark"); Text("Impor Excel Sepran didukung").font(.caption).foregroundStyle(.secondary) }.font(.caption).padding(.bottom, 20)
                    }.padding(.horizontal, 14).navigationSplitViewColumnWidth(240)
                } detail: {
                    VStack(alignment: .leading, spacing: 0) {
                        HStack { VStack(alignment: .leading, spacing: 5) { Text(section).font(.system(size: 28, weight: .semibold)); Text("Kelola keuangan Anda, satu transaksi setiap kali.").foregroundStyle(.secondary) }; Spacer(); if lock.enabled { Button { lock.locked = true } label: { Image(systemName: "lock") } }; Button { newEntry = true } label: { Label("Tambah transaksi", systemImage: "plus") }.buttonStyle(.borderedProminent).tint(accent) }.padding(28)
                        Divider()
                        Group {
                            switch section {
                            case "Transaksi": TransactionsView(edit: $editEntry)
                            case "Dompet": WalletsView()
                            case "Kategori": CategoriesView()
                            case "Utang & piutang": DebtsView()
                            case "Laporan": ReportsView()
                            case "Backup & pengaturan": SettingsView()
                            default: DashboardView(edit: $editEntry)
                            }
                        }.frame(maxWidth: .infinity, maxHeight: .infinity)
                        if !store.message.isEmpty { HStack { Image(systemName: "info.circle"); Text(store.message).font(.callout); Spacer(); Button { store.message = "" } label: { Image(systemName: "xmark") } }.padding(12).background(accent.opacity(0.1)) }
                    }.background(Color(nsColor: .windowBackgroundColor))
                }
            }
        }.tint(accent).preferredColorScheme(appearance == "Gelap" ? .dark : appearance == "Terang" ? .light : nil)
        .sheet(isPresented: $newEntry) { EntryForm().environmentObject(store) }
        .sheet(item: $editEntry) { EntryForm(existing: $0).environmentObject(store) }
        .onChange(of: scenePhase) { _, phase in if phase == .background && lock.enabled { lock.locked = true }; if phase == .active && !lock.locked { automaticBackup() } }
        .onChange(of: lock.locked) { _, locked in if locked { newEntry = false; editEntry = nil } else { automaticBackup() } }
        .onAppear { automaticBackup() }
        .onReceive(NotificationCenter.default.publisher(for: NSApplication.didResignActiveNotification)) { _ in
            if lock.enabled { lock.locked = true }
        }
    }
    func automaticBackup() {
        if UserDefaults.standard.bool(forKey: "weeklyMailReminder"), !lock.locked, !store.ledger.entries.isEmpty {
            let last = UserDefaults.standard.object(forKey: "lastMailBackup") as? Date ?? .distantPast
            if Date().timeIntervalSince(last) > 7 * 86400 && store.message.isEmpty { store.message = "Sudah lebih dari seminggu sejak backup ke Gmail. Buka Backup & pengaturan → Kirim backup ke Gmail." }
        }
        guard !lock.locked, !store.loadFailed, drive.connected, UserDefaults.standard.bool(forKey: "automaticBackup"), !drive.busy else { return }
        let last = UserDefaults.standard.object(forKey: "lastCloudBackup") as? Date ?? .distantPast
        guard Date().timeIntervalSince(last) > 86400 else { return }
        drive.run { try await drive.upload(encoder.encode(store.ledger)) }
    }
}
struct LockView: View {
    @EnvironmentObject var lock: Lock; @State<String> var pin = ""
    var body: some View { VStack(spacing: 20) { Image(systemName: "lock.shield").font(.system(size: 60)).foregroundStyle(accent); Text("Buka SakuMac").font(.largeTitle.bold()); SecureField("PIN", text: $pin).textFieldStyle(.roundedBorder).frame(width: 240).onSubmit { lock.unlock(pin); pin = "" }; HStack { Button("Buka dengan PIN") { lock.unlock(pin); pin = "" }.buttonStyle(.borderedProminent); Button("Touch ID") { Task { await lock.biometric() } } }; Text(lock.error).foregroundStyle(.red) }.frame(maxWidth: .infinity, maxHeight: .infinity) }
}
struct Metric: View {
    var title: String; var value: Int64; var icon: String; var color: Color = accent
    var body: some View { VStack(alignment: .leading, spacing: 14) { HStack { Text(title).foregroundStyle(.secondary); Spacer(); Image(systemName: icon).foregroundStyle(color) }; Text(money(value)).font(.system(size: 23, weight: .semibold)).minimumScaleFactor(0.6).lineLimit(1) }.padding(22).frame(maxWidth: .infinity, alignment: .leading).background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 16)) }
}
struct EntryRow: View {
    @EnvironmentObject var store: Store; var entry: Entry; var edit: (Entry) -> Void
    var body: some View {
        HStack(spacing: 15) {
            Image(systemName: entry.kind == .income ? "arrow.down.left" : entry.kind == .expense ? "arrow.up.right" : "arrow.left.arrow.right").font(.title3).foregroundStyle(entry.kind == .expense ? .red : accent).frame(width: 42, height: 42).background(accent.opacity(0.08), in: RoundedRectangle(cornerRadius: 10))
            VStack(alignment: .leading, spacing: 5) { Text(entry.note.isEmpty ? (entry.kind == .transfer ? "Transfer dompet" : store.ledger.categoryName(entry.category)) : entry.note).fontWeight(.medium); Text("\(entry.date.formatted(date: .abbreviated, time: .shortened)) · \(store.ledger.walletName(entry.wallet))\(entry.kind == .transfer ? " → " + store.ledger.walletName(entry.destination) : " · " + store.ledger.categoryName(entry.category))").font(.caption).foregroundStyle(.secondary) }
            Spacer(); Text((entry.kind == .expense ? "− " : entry.kind == .income ? "+ " : "") + money(entry.amount)).fontWeight(.semibold).foregroundStyle(entry.kind == .expense ? .red : .primary)
            Menu { Button("Edit") { edit(entry) }; Button("Ulangi transaksi") { var e = entry; e.id = UUID(); e.date = Date(); edit(e) }; Button("Hapus", role: .destructive) { do { try store.delete(entry) } catch { store.message = error.localizedDescription } } } label: { Image(systemName: "ellipsis") }.menuStyle(.borderlessButton).frame(width: 24)
        }.padding(.vertical, 10)
    }
}
struct DashboardView: View {
    @EnvironmentObject var store: Store; @Binding var edit: Entry?
    var current: [Entry] { let cal = Calendar.current; let day = store.ledger.cycleDay; let today = Date(); let base = cal.date(from: cal.dateComponents([.year, .month], from: today))!; var start = cal.date(byAdding: .day, value: day-1, to: base)!; if start > today { start = cal.date(byAdding: .month, value: -1, to: start)! }; let end = cal.date(byAdding: .month, value: 1, to: start)!; return store.ledger.entries.filter { $0.date >= start && $0.date < end } }
    var body: some View {
        ScrollView { VStack(alignment: .leading, spacing: 26) {
            HStack(spacing: 16) { Metric(title: "Saldo seluruh dompet", value: store.ledger.wallets.reduce(0) { $0 + store.ledger.balance($1.id) }, icon: "wallet.bifold"); Metric(title: "Pemasukan periode ini", value: current.filter { $0.kind == .income }.reduce(0) { $0 + $1.amount }, icon: "arrow.down.left"); Metric(title: "Pengeluaran periode ini", value: current.filter { $0.kind == .expense }.reduce(0) { $0 + $1.amount }, icon: "arrow.up.right", color: .red) }
            HStack { Text("Dompet Anda").font(.title3.bold()); Spacer(); Text("Periode dimulai tanggal \(store.ledger.cycleDay)").font(.caption).foregroundStyle(.secondary) }
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 220))], spacing: 14) { ForEach(store.ledger.wallets) { w in HStack { Image(systemName: "wallet.bifold.fill").foregroundStyle(accent); VStack(alignment: .leading, spacing: 8) { Text(w.name).foregroundStyle(.secondary); Text(money(store.ledger.balance(w.id))).font(.title3.bold()) }; Spacer() }.padding(20).background(accent.opacity(0.07), in: RoundedRectangle(cornerRadius: 12)) } }
            Text("Transaksi terbaru").font(.title3.bold())
            if store.ledger.entries.isEmpty { ContentUnavailableView("Mulai catat keuangan Anda", systemImage: "note.text.badge.plus", description: Text("Tambahkan saldo awal dompet, lalu catat pemasukan dan pengeluaran.")) }
            else { VStack { ForEach(Array(store.ledger.entries.sorted { $0.date > $1.date }.prefix(10))) { e in EntryRow(entry: e) { edit = $0 }; Divider() } }.padding(18).background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 14)) }
        }.padding(28) }
    }
}
struct TransactionsView: View {
    @EnvironmentObject var store: Store; @Binding var edit: Entry?; @State<String> var search = ""; @State<String> var kind = "Semua"; @State<UUID?> var wallet: UUID?; @State<Bool> var limited = false; @State<Date> var start = Calendar.current.date(from: Calendar.current.dateComponents([.year, .month], from: Date()))!; @State<Date> var end = Date()
    var entries: [Entry] { store.ledger.entries.filter { e in (kind == "Semua" || e.kind.rawValue == kind) && (wallet == nil || wallet == e.wallet || wallet == e.destination) && (!limited || (e.date >= Calendar.current.startOfDay(for: start) && e.date < Calendar.current.date(byAdding: .day, value: 1, to: Calendar.current.startOfDay(for: end))!)) && (search.isEmpty || (e.note + store.ledger.categoryName(e.category) + store.ledger.walletName(e.wallet)).localizedCaseInsensitiveContains(search)) }.sorted { $0.date > $1.date } }
    var body: some View { VStack(spacing: 16) {
        HStack { TextField("Cari catatan, kategori, dompet…", text: $search).textFieldStyle(.roundedBorder); Picker("Jenis", selection: $kind) { Text("Semua").tag("Semua"); ForEach(Kind.allCases, id: \.self) { Text($0.rawValue).tag($0.rawValue) } }.frame(width: 200); Picker("Dompet", selection: $wallet) { Text("Semua").tag(nil as UUID?); ForEach(store.ledger.wallets) { Text($0.name).tag(Optional($0.id)) } }.frame(width: 180) }
        HStack { Toggle("Filter tanggal", isOn: $limited); if limited { DatePicker("Dari", selection: $start, displayedComponents: .date); DatePicker("Sampai", selection: $end, displayedComponents: .date) }; Spacer(); Text("\(entries.count) transaksi").foregroundStyle(.secondary) }
        List { ForEach(entries) { e in EntryRow(entry: e) { edit = $0 } } }.listStyle(.plain)
    }.padding(28) }
}
struct EntryForm: View {
    @EnvironmentObject var store: Store; @Environment(\.dismiss) var dismiss
    var existing: Entry? = nil
    @State<Kind> var kind: Kind = .expense; @State<String> var nominal = ""; @State<Date> var date = Date(); @State<UUID?> var wallet: UUID?; @State<UUID?> var destination: UUID?; @State<UUID?> var category: UUID?; @State<String> var note = ""; @State<String> var error = ""
    var categories: [Category] { store.ledger.categories.filter { $0.income == (kind == .income) } }
    var body: some View { VStack(alignment: .leading, spacing: 20) {
        Text(existing == nil ? "Tambah transaksi" : "Edit / ulangi transaksi").font(.title2.bold())
        Form {
            Picker("Jenis", selection: $kind) { ForEach(Kind.allCases, id: \.self) { Text($0.rawValue).tag($0) } }.pickerStyle(.segmented)
            TextField("Nominal (Rupiah tanpa pemisah)", text: $nominal)
            DatePicker("Tanggal dan waktu", selection: $date)
            Picker("Dompet", selection: $wallet) { ForEach(store.ledger.wallets) { Text($0.name).tag(Optional($0.id)) } }
            if kind == .transfer { Picker("Dompet tujuan", selection: $destination) { Text("Pilih dompet").tag(nil as UUID?); ForEach(store.ledger.wallets.filter { $0.id != wallet }) { Text($0.name).tag(Optional($0.id)) } } }
            else { Picker("Kategori", selection: $category) { Text("Tanpa kategori").tag(nil as UUID?); ForEach(categories) { Text($0.name).tag(Optional($0.id)) } } }
            TextField("Catatan", text: $note)
        }.formStyle(.grouped)
        if !error.isEmpty { Text(error).foregroundStyle(.red) }
        HStack { Button("Batal") { dismiss() }.keyboardShortcut(.cancelAction); Spacer(); Button("Simpan") { save() }.buttonStyle(.borderedProminent).keyboardShortcut(.defaultAction) }
    }.padding(28).frame(width: 560).onAppear { wallet = existing?.wallet ?? store.ledger.wallets.first?.id; if let e = existing { kind = e.kind; nominal = String(e.amount); date = e.date; destination = e.destination; category = e.category; note = e.note } }.onChange(of: kind) { _, _ in if !categories.contains(where: { $0.id == category }) { category = nil }; if kind != .transfer { destination = nil } } }
    func save() { do { guard let w = wallet else { throw AppError.message("Pilih dompet.") }; let n = try amount(nominal); let e = Entry(id: existing?.id ?? UUID(), date: date, kind: kind, amount: n, wallet: w, destination: kind == .transfer ? destination : nil, category: kind == .transfer ? nil : category, note: note); try store.upsert(e); dismiss() } catch { self.error = error.localizedDescription } }
}
struct WalletsView: View {
    @EnvironmentObject var store: Store; @State<String> var name = ""; @State<String> var opening = "0"; @State<Wallet?> var selected: Wallet?; @State<Bool> var negative = false
    var body: some View { VStack(alignment: .leading, spacing: 18) {
        HStack { TextField("Nama dompet", text: $name); TextField("Saldo awal", text: $opening).frame(width: 180); Toggle("Negatif", isOn: $negative); Button(selected == nil ? "Tambah" : "Simpan") { do { var l = store.ledger; let n = try amount(opening) * (negative ? -1 : 1); guard !name.trimmingCharacters(in: .whitespaces).isEmpty, !l.wallets.contains(where: { $0.name == name && $0.id != selected?.id }) else { throw AppError.message("Nama dompet kosong atau sudah digunakan.") }; if let w = selected, let i = l.wallets.firstIndex(where: { $0.id == w.id }) { l.wallets[i].name = name; l.wallets[i].opening = n } else { l.wallets.append(Wallet(name: name, opening: n)) }; try store.commit(l); name = ""; opening = "0"; selected = nil; negative = false } catch { store.message = error.localizedDescription } }; if selected != nil { Button("Batal") { selected = nil; name = ""; opening = "0"; negative = false } } }.textFieldStyle(.roundedBorder)
        Text("Saldo awal adalah saldo sebelum transaksi pertama. Transfer antar-dompet tidak dihitung sebagai pemasukan/pengeluaran.").font(.caption).foregroundStyle(.secondary)
        List { ForEach(store.ledger.wallets) { w in HStack { VStack(alignment: .leading) { Text(w.name).font(.headline); Text("Saldo awal: \(money(w.opening))").foregroundStyle(.secondary) }; Spacer(); Text(money(store.ledger.balance(w.id))).font(.title3.bold()); Button("Edit") { selected = w; name = w.name; opening = String(abs(w.opening)); negative = w.opening < 0 }; Button("Hapus", role: .destructive) { do { guard store.ledger.wallets.count > 1, !store.ledger.entries.contains(where: { $0.wallet == w.id || $0.destination == w.id }) else { throw AppError.message("Dompet yang memiliki transaksi atau dompet terakhir tidak dapat dihapus.") }; var l = store.ledger; l.wallets.removeAll { $0.id == w.id }; try store.commit(l) } catch { store.message = error.localizedDescription } } }.padding(.vertical, 12) } }
    }.padding(28) }
}
struct CategoriesView: View {
    @EnvironmentObject var store: Store; @State<String> var name = ""; @State<Bool> var income = false; @State<Category?> var selected: Category?
    var body: some View { VStack(alignment: .leading, spacing: 18) {
        HStack { TextField("Nama kategori", text: $name).textFieldStyle(.roundedBorder); Toggle("Pemasukan", isOn: $income); Button(selected == nil ? "Tambah" : "Simpan") { do { var l = store.ledger; guard !name.trimmingCharacters(in: .whitespaces).isEmpty, !l.categories.contains(where: { $0.name == name && $0.income == income && $0.id != selected?.id }) else { throw AppError.message("Nama kategori kosong atau sudah digunakan.") }; if let c = selected, let i = l.categories.firstIndex(where: { $0.id == c.id }) { l.categories[i].name = name; l.categories[i].income = income } else { l.categories.append(Category(name: name, income: income)) }; try store.commit(l); name = ""; selected = nil } catch { store.message = error.localizedDescription } }; if selected != nil { Button("Batal") { selected = nil; name = "" } } }
        List { ForEach(store.ledger.categories) { c in HStack { Label(c.name, systemImage: c.income ? "arrow.down.left" : "tag"); Spacer(); Text(c.income ? "Pemasukan" : "Pengeluaran").foregroundStyle(.secondary); Button("Edit") { selected = c; name = c.name; income = c.income }; Button("Hapus", role: .destructive) { do { guard !store.ledger.entries.contains(where: { $0.category == c.id }) else { throw AppError.message("Kategori sedang digunakan oleh transaksi.") }; var l = store.ledger; l.categories.removeAll { $0.id == c.id }; try store.commit(l) } catch { store.message = error.localizedDescription } } }.padding(.vertical, 10) } }
    }.padding(28) }
}
struct DebtsView: View {
    @EnvironmentObject var store: Store; @State<Bool> var newDebt = false; @State<Debt?> var paying: Debt?
    var body: some View { VStack(alignment: .leading, spacing: 18) {
        HStack { Metric(title: "Utang belum lunas", value: store.ledger.debts.filter { !$0.receivable }.reduce(0) { $0 + $1.remaining }, icon: "arrow.up.right", color: .red); Metric(title: "Piutang belum lunas", value: store.ledger.debts.filter { $0.receivable }.reduce(0) { $0 + $1.remaining }, icon: "arrow.down.left") }
        HStack { Text("Daftar utang & piutang").font(.title3.bold()); Spacer(); Button("Tambah utang / piutang") { newDebt = true } }
        Text("Catatan pokok tidak mengubah saldo. Catat penerimaan/pemberian awal melalui transaksi; pembayaran di sini otomatis mengubah saldo.").font(.caption).foregroundStyle(.secondary)
        List { ForEach(store.ledger.debts) { d in HStack { VStack(alignment: .leading, spacing: 6) { Text(d.name).font(.headline); Text("\(d.receivable ? "Piutang" : "Utang") · Jatuh tempo \(d.due.formatted(date: .abbreviated, time: .omitted))").foregroundStyle(d.due < Date() && d.remaining > 0 ? .red : .secondary); Text("Pokok \(money(d.amount)) · \(d.payments.count) pembayaran").font(.caption).foregroundStyle(.secondary); if !d.note.isEmpty { Text(d.note).font(.caption) } }; Spacer(); Text(money(d.remaining)).font(.title3.bold()); Button(d.remaining == 0 ? "Lunas" : "Bayar / terima") { paying = d }.disabled(d.remaining == 0); Button("Hapus", role: .destructive) { do { guard d.payments.isEmpty else { throw AppError.message("Catatan dengan pembayaran tidak dapat dihapus.") }; var l = store.ledger; l.debts.removeAll { $0.id == d.id }; try store.commit(l) } catch { store.message = error.localizedDescription } } }.padding(.vertical, 12) } }
    }.padding(28).sheet(isPresented: $newDebt) { DebtForm().environmentObject(store) }.sheet(item: $paying) { PayForm(debt: $0).environmentObject(store) } }
}
struct DebtForm: View {
    @EnvironmentObject var store: Store; @Environment(\.dismiss) var dismiss; @State<String> var name = ""; @State<String> var nominal = ""; @State<Bool> var receivable = false; @State<Date> var date = Date(); @State<Date> var due = Date(); @State<String> var note = ""; @State<String> var error = ""
    var body: some View { VStack(spacing: 18) { Text("Catat utang / piutang").font(.title2.bold()); Form { TextField("Nama pihak", text: $name); Toggle("Piutang (orang lain berutang kepada saya)", isOn: $receivable); TextField("Nominal Rupiah", text: $nominal); DatePicker("Tanggal", selection: $date, displayedComponents: .date); DatePicker("Jatuh tempo", selection: $due, displayedComponents: .date); TextField("Catatan", text: $note) }.formStyle(.grouped); Text(error).foregroundStyle(.red); HStack { Button("Batal") { dismiss() }; Spacer(); Button("Simpan") { do { var l = store.ledger; l.debts.append(Debt(name: name, receivable: receivable, amount: try amount(nominal), date: date, due: due, note: note)); try store.commit(l); dismiss() } catch { self.error = error.localizedDescription } }.buttonStyle(.borderedProminent) } }.padding(28).frame(width: 550) }
}
struct PayForm: View {
    @EnvironmentObject var store: Store; @Environment(\.dismiss) var dismiss; var debt: Debt; @State<String> var nominal = ""; @State<UUID?> var wallet: UUID?; @State<String> var error = ""
    var body: some View { VStack(spacing: 18) { Text("Pembayaran: \(debt.name)").font(.title2.bold()); Text("Sisa \(money(debt.remaining))"); TextField("Nominal pembayaran", text: $nominal).textFieldStyle(.roundedBorder); Picker("Dompet", selection: $wallet) { ForEach(store.ledger.wallets) { Text($0.name).tag(Optional($0.id)) } }; Text(error).foregroundStyle(.red); HStack { Button("Batal") { dismiss() }; Spacer(); Button("Simpan pembayaran") { do { guard let w = wallet else { return }; try store.pay(debt.id, amount: amount(nominal), wallet: w); dismiss() } catch { self.error = error.localizedDescription } }.buttonStyle(.borderedProminent) } }.padding(28).frame(width: 500).onAppear { wallet = store.ledger.wallets.first?.id; nominal = String(debt.remaining) } }
}
struct SettingsView: View {
    @EnvironmentObject var store: Store; @EnvironmentObject var lock: Lock; @EnvironmentObject var drive: GoogleDrive
    @AppStorage("appearance") var appearance = "Sistem"; @AppStorage("automaticBackup") var automatic = false; @AppStorage("gmailAddress") var gmail = ""; @AppStorage("weeklyMailReminder") var weeklyMail = false
    @State<Int> var cycle = 1; @State<String> var pin = ""; @State<String> var pinConfirm = ""; @State<Data?> var restoreData: Data?; @State<String> var preview = ""; @State<Bool> var showRestore = false
    var body: some View { ScrollView { VStack(alignment: .leading, spacing: 24) {
        GroupBox("Tampilan & periode") { VStack(alignment: .leading, spacing: 14) { Picker("Tampilan", selection: $appearance) { ForEach(["Sistem", "Terang", "Gelap"], id: \.self) { Text($0) } }.frame(width: 320); HStack { Stepper("Mulai periode tanggal \(cycle)", value: $cycle, in: 1...28); Button("Simpan periode") { perform { var l = store.ledger; l.cycleDay = cycle; try store.commit(l); store.message = "Periode laporan disimpan." } } }.frame(maxWidth: 500) }.padding(12).frame(maxWidth: .infinity, alignment: .leading) }
        GroupBox("Keamanan") { VStack(alignment: .leading, spacing: 12) { Text(lock.enabled ? "PIN aktif. Aplikasi terkunci saat berpindah ke latar belakang." : "PIN belum diaktifkan."); HStack { SecureField("PIN baru (6–12 angka)", text: $pin); SecureField("Ulangi PIN", text: $pinConfirm); Button("Aktifkan / ubah PIN") { perform { guard pin == pinConfirm else { throw AppError.message("Konfirmasi PIN tidak sama.") }; try lock.setPIN(pin); pin = ""; pinConfirm = ""; store.message = "PIN tersimpan di Keychain." } }; if lock.enabled { Button("Nonaktifkan") { lock.disable() } } }.textFieldStyle(.roundedBorder); Text("PIN mengunci tampilan; berkas keuangan dan backup JSON tidak dienkripsi. Token Google disimpan di Keychain.").font(.caption).foregroundStyle(.secondary) }.padding(12) }
        GroupBox("Backup lokal & ekspor") { VStack(alignment: .leading, spacing: 14) {
            HStack { Button("Simpan backup lengkap") { perform { try saveFile("SakuMac-backup.json", type: .json, data: encoder.encode(store.ledger)) } }; Button("Pulihkan backup…") { perform { try openFile([.json, .data]) { try prepareRestore(Data(contentsOf: $0)) } } }; Button("Ekspor semua CSV") { perform { try saveFile("SakuMac-transaksi.csv", type: .commaSeparatedText, data: Data(CSV.export(store.ledger, entries: store.ledger.entries).utf8)) } } }
            HStack { Button("Impor CSV SakuMac…") { perform { try openFile([.commaSeparatedText, .plainText]) { u in let (l, n) = try CSV.importing(String(contentsOf: u, encoding: .utf8), into: store.ledger); try store.commit(l); store.message = "\(n) transaksi ditambahkan. Duplikat identik dilewati." } } }; Button("Impor Excel Sepran…") { perform { try openFile([UTType(filenameExtension: "xlsx") ?? .data]) { u in let (l, n, skip) = try Sepran.importing(file: u, into: store.ledger); try store.commit(l); store.message = "Sepran: \(n) transaksi baru ditambahkan ke dompet \"\(Sepran.walletName)\", \(skip) sudah ada dilewati." } } }; Button("Buka folder data") { NSWorkspace.shared.open(store.directory) } }
            Text("Backup mencakup dompet, saldo awal, kategori, transaksi, utang/piutang, pembayaran, dan periode laporan. Pemulihan mengganti data setelah pratinjau; salinan data sebelum perubahan disimpan sebagai Before-change.json.").font(.caption).foregroundStyle(.secondary)
        }.padding(12).frame(maxWidth: .infinity, alignment: .leading) }
        GroupBox("Backup ke Gmail (email)") { VStack(alignment: .leading, spacing: 12) {
            Text("Mengirim berkas backup lengkap sebagai lampiran email ke alamat Gmail Anda. Tidak perlu pengaturan Google Cloud.").font(.callout).foregroundStyle(.secondary)
            HStack { TextField("Alamat Gmail Anda", text: $gmail).textFieldStyle(.roundedBorder).frame(maxWidth: 340); Button("Kirim backup ke Gmail") { perform { try mailBackup() } }.buttonStyle(.borderedProminent).tint(accent) }
            Toggle("Ingatkan saya mengirim backup ke Gmail setiap minggu", isOn: $weeklyMail)
            if let last = UserDefaults.standard.object(forKey: "lastMailBackup") as? Date { Text("Backup email terakhir disiapkan: \(last.formatted())").font(.caption).foregroundStyle(.secondary) }
            Text("Aplikasi Mail akan terbuka dengan lampiran; periksa lalu klik Kirim. Mail perlu sudah terhubung ke akun email (Pengaturan Sistem → Akun Internet → Google). Untuk memulihkan: unduh lampiran dari Gmail, lalu pakai Pulihkan backup….").font(.caption).foregroundStyle(.secondary)
        }.padding(12).frame(maxWidth: .infinity, alignment: .leading) }
        GroupBox("Akun Google / Gmail — backup di Google Drive") { VStack(alignment: .leading, spacing: 14) {
            HStack { Label(drive.connected ? "Google Drive terhubung" : drive.configured ? "Siap login Google" : "Konfigurasi OAuth diperlukan", systemImage: drive.connected ? "checkmark.icloud" : "icloud"); Spacer(); if drive.busy { ProgressView().controlSize(.small) } }
            Text("Masuk menggunakan akun Google yang memiliki alamat Gmail. Backup disimpan di Google Drive akun tersebut.").font(.callout).foregroundStyle(.secondary)
            HStack { Button("Impor konfigurasi Google…") { perform { try openFile([.json]) { try drive.configure(Data(contentsOf: $0)) } } }.disabled(drive.busy); Button("Hubungkan akun Google") { drive.run { try await drive.login() } }.disabled(!drive.configured || drive.busy); if drive.connected { Button("Putuskan akun") { drive.disconnect() }.disabled(drive.busy) } }
            HStack { Button("Upload backup sekarang") { drive.run { guard !store.loadFailed else { throw AppError.message("Data lokal gagal dibuka; upload dihentikan.") }; try await drive.upload(encoder.encode(store.ledger)) } }; Button("Daftar backup Google Drive") { drive.run { try await drive.list() } } }.disabled(!drive.connected || drive.busy)
            Toggle("Backup otomatis setiap hari ketika aplikasi aktif dan terbuka", isOn: $automatic).disabled(!drive.connected)
            if let last = UserDefaults.standard.object(forKey: "lastCloudBackup") as? Date { Text("Upload terakhir: \(last.formatted())").font(.caption).foregroundStyle(.secondary) }
            if !drive.status.isEmpty { Text(drive.status).font(.callout).textSelection(.enabled) }
            ForEach(drive.files) { f in HStack { Text(f.name).font(.caption); Spacer(); Button("Pulihkan…") { drive.run { let data = try await drive.download(f); try prepareRestore(data) } }.disabled(drive.busy) } }
            DisclosureGroup("Cara menyiapkan login Google") { Text("1. Buka Google Cloud Console dan buat/pilih proyek.\n2. Aktifkan Google Drive API.\n3. Atur OAuth consent screen dan tambahkan akun Anda sebagai test user.\n4. Buat OAuth client ID dengan jenis Desktop app.\n5. Unduh berkas JSON, lalu impor dengan tombol di atas.\n6. Hubungkan akun Google dan izinkan akses berkas yang dibuat aplikasi.").font(.callout).frame(maxWidth: .infinity, alignment: .leading); Link("Buka Google Cloud Console", destination: URL(string: "https://console.cloud.google.com/apis/credentials")!) }.padding(.top, 8)
        }.padding(12).frame(maxWidth: .infinity, alignment: .leading) }
        GroupBox("Data dari Sepran") { VStack(alignment: .leading, spacing: 10) { Text("Di Sepran: Laporan → pilih rentang tanggal terlengkap → ikon unduh (Excel). Lalu di SakuMac klik Impor Excel Sepran… dan pilih berkas .xlsx tersebut."); Text("Transaksi masuk ke dompet \"Sepran\" dengan kategori sesuai Sepran; Judul dan Catatan digabung ke catatan. Impor ulang ekspor yang lebih baru hanya menambah transaksi baru; transaksi yang sudah diimpor (termasuk yang Anda edit di SakuMac) tidak diubah. Ekspor Sepran tidak memuat nama dompet maupun saldo awal — atur saldo awal dompet Sepran di menu Dompet.").font(.caption).foregroundStyle(.secondary) }.padding(12).frame(maxWidth: .infinity, alignment: .leading) }
        Text("SakuMac 0.1 • Apple Silicon • Dibuat untuk Mac ini • Bukan produk resmi Sepran").font(.caption).foregroundStyle(.secondary)
    }.padding(28) }.onAppear { cycle = store.ledger.cycleDay }.confirmationDialog("Pulihkan backup?", isPresented: $showRestore, titleVisibility: .visible) { Button("Ganti data dengan backup", role: .destructive) { if let d = restoreData { perform { try store.restore(d) } }; restoreData = nil }; Button("Batal", role: .cancel) { restoreData = nil } } message: { Text(preview) } }
    func perform(_ action: () throws -> Void) { do { try action() } catch { store.message = error.localizedDescription } }
    func mailBackup() throws {
        let address = gmail.trimmingCharacters(in: .whitespaces)
        guard address.range(of: #"^[^@\s]+@[^@\s]+\.[^@\s]+$"#, options: .regularExpression) != nil else { throw AppError.message("Masukkan alamat Gmail yang valid.") }
        guard !store.loadFailed else { throw AppError.message("Data lokal gagal dibuka; backup dihentikan.") }
        let day = ISO8601DateFormatter.string(from: Date(), timeZone: .current, formatOptions: [.withFullDate])
        let folder = store.directory.appendingPathComponent("Backup email", isDirectory: true); try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let file = folder.appendingPathComponent("SakuMac-backup-\(day).json"); try encoder.encode(store.ledger).write(to: file, options: .atomic)
        guard let service = NSSharingService(named: .composeEmail), service.canPerform(withItems: [file]) else { NSWorkspace.shared.activateFileViewerSelecting([file]); throw AppError.message("Aplikasi Mail tidak tersedia. Berkas backup ditampilkan di Finder; lampirkan manual ke email Gmail.") }
        service.recipients = [address]; service.subject = "Backup SakuMac \(day)"
        service.perform(withItems: ["Backup SakuMac \(day): \(store.ledger.entries.count) transaksi, \(store.ledger.wallets.count) dompet. Pulihkan lewat SakuMac → Backup & pengaturan → Pulihkan backup….", file])
        UserDefaults.standard.set(Date(), forKey: "lastMailBackup"); store.message = "Email backup disiapkan di Mail untuk \(address). Klik Kirim di Mail."
    }
    func prepareRestore(_ data: Data) throws { let l = try decoder.decode(Ledger.self, from: data); try l.validate(); restoreData = data; preview = "Backup berisi \(l.entries.count) transaksi, \(l.wallets.count) dompet, dan \(l.debts.count) utang/piutang. Data saat ini akan diganti. Salinan data sebelumnya disimpan di folder data."; showRestore = true }
}
struct PDFReport {
    @MainActor static func make(_ l: Ledger, entries: [Entry], start: Date, end: Date) throws -> Data {
        let data = NSMutableData(); guard let consumer = CGDataConsumer(data: data as CFMutableData) else { throw AppError.message("Tidak dapat membuat PDF.") }
        var bounds = CGRect(x: 0, y: 0, width: 595, height: 842); guard let context = CGContext(consumer: consumer, mediaBox: &bounds, nil) else { throw AppError.message("Tidak dapat membuat PDF.") }
        var lines = ["SAKUMAC — LAPORAN KEUANGAN", "\(start.formatted(date: .abbreviated, time: .omitted)) – \(end.formatted(date: .abbreviated, time: .omitted))", "Pemasukan: \(money(entries.filter { $0.kind == .income }.reduce(0) { $0 + $1.amount }))", "Pengeluaran: \(money(entries.filter { $0.kind == .expense }.reduce(0) { $0 + $1.amount }))", ""]
        for e in entries.sorted(by: { $0.date < $1.date }) { lines.append("\(e.date.formatted(date: .numeric, time: .shortened)) | \(e.kind.rawValue) | \(money(e.amount))"); lines.append("\(l.walletName(e.wallet))\(e.kind == .transfer ? " → " + l.walletName(e.destination) : " | " + l.categoryName(e.category)) | \(e.note)") }
        lines = lines.flatMap { line in
            line.components(separatedBy: "\n").flatMap { part -> [String] in
                if part.isEmpty { return [""] }
                let characters = Array(part)
                return stride(from: 0, to: characters.count, by: 95).map { String(characters[$0..<min($0 + 95, characters.count)]) }
            }
        }
        var index = 0; var page = 0
        while index < lines.count { page += 1; context.beginPDFPage(nil); context.saveGState(); context.translateBy(x: 0, y: 842); context.scaleBy(x: 1, y: -1); let graphics = NSGraphicsContext(cgContext: context, flipped: true); NSGraphicsContext.saveGraphicsState(); NSGraphicsContext.current = graphics
            var y: CGFloat = 40
            while index < lines.count && y < 760 {
                let line = lines[index]; let attrs: [NSAttributedString.Key: Any] = [.font: NSFont.systemFont(ofSize: index == 0 ? 18 : 10), .foregroundColor: NSColor.black]
                let s = NSAttributedString(string: line, attributes: attrs); let rect = s.boundingRect(with: CGSize(width: 510, height: 2000), options: [.usesLineFragmentOrigin, .usesFontLeading]); let height = max(18, ceil(rect.height) + 6)
                if y + height > 780 { break }; s.draw(with: CGRect(x: 42, y: y, width: 510, height: height), options: [.usesLineFragmentOrigin, .usesFontLeading]); y += height; index += 1
            }
            NSAttributedString(string: "SakuMac • Halaman \(page)", attributes: [.font: NSFont.systemFont(ofSize: 9), .foregroundColor: NSColor.gray]).draw(at: CGPoint(x: 42, y: 800)); NSGraphicsContext.restoreGraphicsState(); context.restoreGState(); context.endPDFPage()
        }; context.closePDF(); return data as Data
    }
}
