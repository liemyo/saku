import Foundation
import Combine

enum AppError: LocalizedError { case message(String); var errorDescription: String? { if case .message(let s) = self { return s }; return nil } }
func money(_ value: Int64) -> String { let f = NumberFormatter(); f.numberStyle = .currency; f.currencyCode = "IDR"; f.locale = Locale(identifier: "id_ID"); f.maximumFractionDigits = 0; return f.string(from: NSNumber(value: value)) ?? "Rp \(value)" }
func amount(_ text: String) throws -> Int64 {
    let s = text.trimmingCharacters(in: .whitespacesAndNewlines)
    guard !s.isEmpty, s.allSatisfy({ $0.isNumber }), let n = Int64(s), n <= 1_000_000_000_000_000 else { throw AppError.message("Masukkan nominal Rupiah bulat tanpa titik/koma, maksimal 1 kuadriliun.") }; return n
}
struct Wallet: Codable, Identifiable, Equatable { var id = UUID(); var name: String; var opening: Int64 = 0 }
struct Category: Codable, Identifiable, Equatable { var id = UUID(); var name: String; var income: Bool = false }
enum Kind: String, Codable, CaseIterable { case expense = "Pengeluaran", income = "Pemasukan", transfer = "Transfer" }
struct Entry: Codable, Identifiable, Equatable {
    var id = UUID(); var date = Date(); var kind: Kind; var amount: Int64; var wallet: UUID; var destination: UUID?; var category: UUID?; var note: String = ""
}
struct Payment: Codable, Identifiable { var id = UUID(); var date = Date(); var amount: Int64; var wallet: UUID; var entry: UUID }
struct Debt: Codable, Identifiable {
    var id = UUID(); var name: String; var receivable: Bool; var amount: Int64; var date = Date(); var due = Date(); var note = ""; var payments: [Payment] = []
    var remaining: Int64 { amount - payments.reduce(0) { $0 + $1.amount } }
}
struct Ledger: Codable {
    var format = "SakuMac"; var version = 1
    var wallets = [Wallet(name: "Tunai"), Wallet(name: "Bank")]
    var categories = [Category(name: "Makan & minum"), Category(name: "Transportasi"), Category(name: "Belanja"), Category(name: "Tagihan"), Category(name: "Kesehatan"), Category(name: "Lainnya"), Category(name: "Gaji", income: true), Category(name: "Pendapatan lain", income: true)]
    var entries: [Entry] = []; var debts: [Debt] = []; var cycleDay = 1
    func validate() throws {
        guard format == "SakuMac", version == 1 else { throw AppError.message("Format backup belum didukung. Backup Sepran asli memerlukan adaptor berdasarkan contoh berkas.") }
        guard !wallets.isEmpty, (1...28).contains(cycleDay), wallets.count < 10000, entries.count < 1_000_000 else { throw AppError.message("Backup tidak valid.") }
        guard Set(wallets.map(\.id)).count == wallets.count, Set(categories.map(\.id)).count == categories.count, Set(entries.map(\.id)).count == entries.count, Set(debts.map(\.id)).count == debts.count else { throw AppError.message("ID duplikat dalam backup.") }
        let ws = Set(wallets.map(\.id)); let cs = Set(categories.map(\.id))
        guard wallets.allSatisfy({ !$0.name.trimmingCharacters(in: .whitespaces).isEmpty && (-1_000_000_000_000_000...1_000_000_000_000_000).contains($0.opening) }), categories.allSatisfy({ !$0.name.trimmingCharacters(in: .whitespaces).isEmpty }) else { throw AppError.message("Dompet atau kategori tidak valid.") }
        for e in entries {
            guard e.amount > 0, e.amount <= 1_000_000_000_000_000, ws.contains(e.wallet), e.date.timeIntervalSince1970.isFinite else { throw AppError.message("Transaksi tidak valid.") }
            if e.kind == .transfer { guard let d = e.destination, ws.contains(d), d != e.wallet else { throw AppError.message("Dompet transfer tidak valid.") } }
            else if let c = e.category { guard cs.contains(c), categories.first(where: { $0.id == c })!.income == (e.kind == .income) else { throw AppError.message("Kategori transaksi tidak sesuai.") } }
        }
        for d in debts {
            guard d.payments.allSatisfy({ $0.amount > 0 && $0.amount <= 1_000_000_000_000_000 }), d.payments.count < 1000 else { throw AppError.message("Daftar pembayaran tidak valid.") }
            guard d.amount > 0, d.amount <= 1_000_000_000_000_000, !d.name.isEmpty, d.remaining >= 0 else { throw AppError.message("Utang/piutang tidak valid.") }
            for p in d.payments {
                guard p.amount > 0, let e = entries.first(where: { $0.id == p.entry }), e.amount == p.amount, e.wallet == p.wallet, e.kind == (d.receivable ? .income : .expense) else { throw AppError.message("Pembayaran utang tidak konsisten.") }
            }
        }
        // Limit total turnover so all dashboard, report and balance aggregates remain safe.
        var turnover: Int64 = 0
        for n in wallets.map({ abs($0.opening) }) + entries.map(\.amount) + debts.map(\.amount) {
            let (total, overflow) = turnover.addingReportingOverflow(n)
            guard !overflow, total <= 1_000_000_000_000_000_000 else { throw AppError.message("Jumlah keseluruhan melebihi batas aman.") }
            turnover = total
        }
        // Check aggregation before accepting untrusted backups, avoiding arithmetic overflow.
        var totals: [UUID: Int64] = Dictionary(uniqueKeysWithValues: wallets.map { ($0.id, $0.opening) })
        for e in entries {
            let delta = e.kind == .income ? e.amount : -e.amount
            let (n, overflow) = totals[e.wallet, default: 0].addingReportingOverflow(delta)
            guard !overflow else { throw AppError.message("Saldo melebihi batas angka.") }; totals[e.wallet] = n
            if e.kind == .transfer, let d = e.destination { let (n, over) = totals[d, default: 0].addingReportingOverflow(e.amount); guard !over else { throw AppError.message("Saldo melebihi batas angka.") }; totals[d] = n }
        }
    }
    func balance(_ id: UUID) -> Int64 { entries.reduce(wallets.first(where: { $0.id == id })?.opening ?? 0) { v, e in v + (e.wallet == id ? (e.kind == .income ? e.amount : -e.amount) : 0) + (e.kind == .transfer && e.destination == id ? e.amount : 0) } }
    func walletName(_ id: UUID?) -> String { wallets.first(where: { $0.id == id })?.name ?? "—" }
    func categoryName(_ id: UUID?) -> String { categories.first(where: { $0.id == id })?.name ?? "—" }
}
let encoder: JSONEncoder = { let e = JSONEncoder(); e.outputFormatting = [.prettyPrinted, .sortedKeys]; e.dateEncodingStrategy = .iso8601; return e }()
let decoder: JSONDecoder = { let d = JSONDecoder(); d.dateDecodingStrategy = .iso8601; return d }()
@MainActor final class Store: ObservableObject {
    @Published var ledger = Ledger(); @Published var message = ""; @Published var loadFailed = false
    let directory: URL; let file: URL
    init(directory: URL? = nil) {
        self.directory = directory ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("SakuMac", isDirectory: true)
        file = self.directory.appendingPathComponent("ledger.json")
        do { try FileManager.default.createDirectory(at: self.directory, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700]); if FileManager.default.fileExists(atPath: file.path) { let l = try decoder.decode(Ledger.self, from: Data(contentsOf: file)); try l.validate(); ledger = l } }
        catch { loadFailed = true; message = "Data tidak dapat dibuka; berkas asli tetap disimpan. \(error.localizedDescription)" }
    }
    func commit(_ candidate: Ledger) throws {
        guard !loadFailed else { throw AppError.message("Data lama gagal dibuka. Pulihkan backup sebelum mengubah data.") }
        try candidate.validate(); let data = try encoder.encode(candidate); let canonical = try decoder.decode(Ledger.self, from: data)
        if FileManager.default.fileExists(atPath: file.path) {
            let backup = directory.appendingPathComponent("Before-change.json")
            try Data(contentsOf: file).write(to: backup, options: .atomic)
            try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: backup.path)
        }
        try data.write(to: file, options: .atomic); try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: file.path); ledger = canonical
    }
    func restore(_ data: Data) throws {
        let l = try decoder.decode(Ledger.self, from: data); try l.validate()
        let oldFailure = loadFailed; loadFailed = false
        do { try commit(l); message = "Backup dipulihkan: \(l.entries.count) transaksi." } catch { loadFailed = oldFailure; throw error }
    }
    func upsert(_ entry: Entry) throws { var l = ledger; if let i = l.entries.firstIndex(where: { $0.id == entry.id }) { guard !l.debts.contains(where: { $0.payments.contains(where: { $0.entry == entry.id }) }) else { throw AppError.message("Transaksi pembayaran utang tidak dapat diedit langsung.") }; l.entries[i] = entry } else { l.entries.append(entry) }; try commit(l) }
    func delete(_ entry: Entry) throws { guard !ledger.debts.contains(where: { $0.payments.contains(where: { $0.entry == entry.id }) }) else { throw AppError.message("Pembayaran utang tidak dapat dihapus dari daftar transaksi.") }; var l = ledger; l.entries.removeAll { $0.id == entry.id }; try commit(l) }
    func pay(_ id: UUID, amount: Int64, wallet: UUID) throws {
        var l = ledger; guard let i = l.debts.firstIndex(where: { $0.id == id }), amount > 0, amount <= l.debts[i].remaining else { throw AppError.message("Nominal pembayaran melebihi sisa utang/piutang.") }
        let d = l.debts[i]; let e = Entry(kind: d.receivable ? .income : .expense, amount: amount, wallet: wallet, note: "Pembayaran \(d.receivable ? "piutang" : "utang"): \(d.name)")
        l.entries.append(e); l.debts[i].payments.append(Payment(amount: amount, wallet: wallet, entry: e.id)); try commit(l)
    }
}
struct CSV {
    static func quote(_ s: String) -> String { "\"" + s.replacingOccurrences(of: "\"", with: "\"\"") + "\"" }
    static func export(_ l: Ledger, entries: [Entry]) -> String {
        let iso = ISO8601DateFormatter()
        let rows = entries.sorted { $0.date < $1.date }.map { e in [e.id.uuidString, iso.string(from: e.date), e.kind.rawValue, String(e.amount), l.walletName(e.wallet), e.destination == nil ? "" : l.walletName(e.destination), e.category == nil ? "" : l.categoryName(e.category), e.note].map(quote).joined(separator: ",") }
        return (["id,date,type,amount,wallet,destination,category,note"] + rows).joined(separator: "\r\n") + "\r\n"
    }
    static func parse(_ text: String) throws -> [[String]] {
        var rows: [[String]] = []; var row: [String] = []; var cell = ""; var quoted = false; var closed = false
        let chars = Array(text.replacingOccurrences(of: "\r\n", with: "\n").replacingOccurrences(of: "\r", with: "\n")); var i = 0
        while i < chars.count { let c = chars[i]
            if quoted { if c == "\"" { if i + 1 < chars.count && chars[i+1] == "\"" { cell.append("\""); i += 1 } else { quoted = false; closed = true } } else { cell.append(c) } }
            else if c == "," { row.append(cell); cell = ""; closed = false }
            else if c == "\n" { row.append(cell); if !row.allSatisfy({ $0.isEmpty }) { rows.append(row) }; row = []; cell = ""; closed = false }
            else if c == "\"" && cell.isEmpty && !closed { quoted = true }
            else { guard !closed, c != "\"" else { throw AppError.message("CSV memiliki kutipan tidak valid.") }; cell.append(c) }; i += 1
        }
        guard !quoted else { throw AppError.message("CSV terpotong: kutipan belum ditutup.") }
        if !cell.isEmpty || !row.isEmpty { row.append(cell); rows.append(row) }; return rows
    }
    static func importing(_ text: String, into original: Ledger) throws -> (Ledger, Int) {
        let rows = try parse(text.trimmingCharacters(in: CharacterSet(charactersIn: "\u{FEFF}")))
        guard let header = rows.first, header == ["id","date","type","amount","wallet","destination","category","note"] else { throw AppError.message("Skema CSV belum dikenali. Gunakan CSV SakuMac; format Sepran akan dipetakan setelah contoh berkas tersedia.") }
        var l = original; var count = 0; let iso = ISO8601DateFormatter()
        func wallet(_ name: String) throws -> UUID { guard !name.isEmpty else { throw AppError.message("Nama dompet kosong.") }; if let w = l.wallets.first(where: { $0.name == name }) { return w.id }; let w = Wallet(name: name); l.wallets.append(w); return w.id }
        for (index, r) in rows.dropFirst().enumerated() {
            guard r.count == 8, let id = UUID(uuidString: r[0]), let date = iso.date(from: r[1]), let kind = Kind(rawValue: r[2]) else { throw AppError.message("CSV baris \(index + 2) tidak valid.") }
            let n = try amount(r[3]); let w = try wallet(r[4]); let dest = r[5].isEmpty ? nil : try wallet(r[5]); var cat: UUID? = nil
            if !r[6].isEmpty { if let c = l.categories.first(where: { $0.name == r[6] && $0.income == (kind == .income) }) { cat = c.id } else { let c = Category(name: r[6], income: kind == .income); l.categories.append(c); cat = c.id } }
            let e = Entry(id: id, date: date, kind: kind, amount: n, wallet: w, destination: dest, category: cat, note: r[7])
            if let existing = l.entries.first(where: { $0.id == id }) { guard existing == e else { throw AppError.message("ID transaksi bertabrakan pada baris \(index + 2). Tidak ada data diubah.") }; continue }
            l.entries.append(e); count += 1
        }; try l.validate(); return (l, count)
    }
}
struct CategoryTotal: Identifiable, Equatable { var id: String { key }; var key: String; var name: String; var total: Int64; var count: Int }
struct MonthTotal: Identifiable, Equatable { var id: Date { month }; var month: Date; var total: Int64; var count: Int }
enum Reports {
    static func key(_ e: Entry) -> String { e.category?.uuidString ?? "none" }
    static func expenses(_ l: Ledger, from start: Date, to end: Date, wallet: UUID? = nil) -> [Entry] { l.entries.filter { $0.kind == .expense && $0.date >= start && $0.date < end && (wallet == nil || $0.wallet == wallet) } }
    static func byCategory(_ l: Ledger, _ entries: [Entry]) -> [CategoryTotal] {
        Dictionary(grouping: entries, by: key).map { k, es in CategoryTotal(key: k, name: es[0].category == nil ? "Tanpa kategori" : l.categoryName(es[0].category), total: es.reduce(0) { $0 + $1.amount }, count: es.count) }
            .sorted { $0.total != $1.total ? $0.total > $1.total : $0.name < $1.name }
    }
    static func monthStart(_ d: Date, _ cal: Calendar = .current) -> Date { cal.date(from: cal.dateComponents([.year, .month], from: d))! }
    /// Monthly expense totals between start and end (exclusive), including empty months.
    static func byMonth(_ entries: [Entry], from start: Date, to end: Date, calendar cal: Calendar = .current) -> [MonthTotal] {
        guard start < end else { return [] }
        let grouped = Dictionary(grouping: entries.filter { $0.date >= start && $0.date < end }) { monthStart($0.date, cal) }
        var out: [MonthTotal] = []; var m = monthStart(start, cal)
        while m < end && out.count < 1200 { let es = grouped[m] ?? []; out.append(MonthTotal(month: m, total: es.reduce(0) { $0 + $1.amount }, count: es.count)); m = cal.date(byAdding: .month, value: 1, to: m)! }
        return out
    }
    static func summaryCSV(_ l: Ledger, categories: [CategoryTotal], months: [MonthTotal], title: String) -> String {
        let f = DateFormatter(); f.dateFormat = "yyyy-MM"; let total = categories.reduce(0) { $0 + $1.total }
        var rows = [CSV.quote(title), "", "kategori,total,transaksi,persen"]
        rows += categories.map { [CSV.quote($0.name), String($0.total), String($0.count), String(format: "%.1f", Double($0.total) / Double(max(1, total)) * 100)].joined(separator: ",") }
        rows += ["", "bulan,total,transaksi"] + months.map { "\(f.string(from: $0.month)),\($0.total),\($0.count)" }
        return rows.joined(separator: "\r\n") + "\r\n"
    }
}
