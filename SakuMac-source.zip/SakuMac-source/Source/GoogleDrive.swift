import Foundation
import AppKit
import Network
import CryptoKit
import Combine

struct OAuthConfig: Codable { var client_id: String; var client_secret: String? }
struct OAuthEnvelope: Codable { var installed: OAuthConfig }
struct Tokens: Codable { var access_token: String; var refresh_token: String?; var expires_in: Double?; var expiresAt: Date? }
struct DriveFile: Codable, Identifiable { var id: String; var name: String; var createdTime: String? }
struct DriveList: Codable { var files: [DriveFile]; var nextPageToken: String? }
@MainActor final class GoogleDrive: ObservableObject {
    @Published var connected = Vault.get("google.tokens") != nil
    @Published var busy = false; @Published var status = ""; @Published var files: [DriveFile] = []
    @Published var configured = Vault.get("google.config") != nil
    var readyCallback: CheckedContinuation<UInt16, Error>?
    var listener: NWListener?; var callback: CheckedContinuation<String, Error>?; var expectedState = ""; var timeout: Task<Void, Never>?
    func configure(_ data: Data) throws {
        let c = try JSONDecoder().decode(OAuthEnvelope.self, from: data).installed
        guard c.client_id.hasSuffix(".apps.googleusercontent.com") else { throw AppError.message("Gunakan konfigurasi OAuth tipe Desktop app dari Google Cloud.") }
        try Vault.set("google.config", JSONEncoder().encode(c)); disconnect(); configured = true; status = "Konfigurasi Google tersimpan."
    }
    func disconnect() { Vault.remove("google.tokens"); connected = false; files = [] }
    func config() throws -> OAuthConfig { guard let d = Vault.get("google.config") else { throw AppError.message("Impor credentials.json OAuth Desktop terlebih dahulu.") }; return try JSONDecoder().decode(OAuthConfig.self, from: d) }
    func base64(_ d: Data) -> String { d.base64EncodedString().replacingOccurrences(of: "+", with: "-").replacingOccurrences(of: "/", with: "_").replacingOccurrences(of: "=", with: "") }
    func random() throws -> String { var d = Data(count: 32); guard d.withUnsafeMutableBytes({ SecRandomCopyBytes(kSecRandomDefault, 32, $0.baseAddress!) }) == errSecSuccess else { throw AppError.message("Tidak dapat membuat kode keamanan.") }; return base64(d) }
    func finish(_ result: Result<String, Error>) { guard let cb = callback else { return }; callback = nil; timeout?.cancel(); timeout = nil; listener?.cancel(); listener = nil; cb.resume(with: result) }
    func login() async throws {
        let c = try config(); let verifier = try random(); expectedState = try random()
        let params = NWParameters.tcp; params.requiredLocalEndpoint = .hostPort(host: "127.0.0.1", port: .any)
        let server = try NWListener(using: params); listener = server
        let port: UInt16 = try await withCheckedThrowingContinuation { continuation in
            readyCallback = continuation
            server.stateUpdateHandler = { state in
                Task { @MainActor in
                    guard let cb = self.readyCallback else { return }
                    switch state {
                    case .ready: self.readyCallback = nil; cb.resume(returning: server.port!.rawValue)
                    case .failed(let error): self.readyCallback = nil; cb.resume(throwing: error)
                    default: break
                    }
                }
            }; server.start(queue: .main)
        }
        server.stateUpdateHandler = nil
        let redirect = "http://127.0.0.1:\(port)/oauth"
        server.newConnectionHandler = { connection in
            connection.start(queue: .main)
            connection.receive(minimumIncompleteLength: 1, maximumLength: 16384) { data, _, _, _ in
                Task { @MainActor in
                    guard let data, let request = String(data: data, encoding: .utf8), let first = request.components(separatedBy: "\r\n").first else { connection.cancel(); return }
                    let parts = first.split(separator: " "); guard parts.count >= 2, parts[0] == "GET", let url = URLComponents(string: "http://127.0.0.1" + String(parts[1])), url.path == "/oauth" else { connection.cancel(); return }
                    let items = url.queryItems ?? []; let state = items.first { $0.name == "state" }?.value
                    guard state == self.expectedState else { connection.cancel(); return }
                    let code = items.first { $0.name == "code" }?.value
                    let body = "Anda dapat kembali ke SakuMac."
                    let response = "HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\nContent-Length: \(body.utf8.count)\r\nConnection: close\r\n\r\n\(body)"
                    connection.send(content: Data(response.utf8), completion: .contentProcessed { _ in connection.cancel() })
                    if let code { self.finish(.success(code)) } else { self.finish(.failure(AppError.message("Login Google dibatalkan atau ditolak."))) }
                }
            }
        }
        var url = URLComponents(string: "https://accounts.google.com/o/oauth2/v2/auth")!
        url.queryItems = ["client_id": c.client_id, "redirect_uri": redirect, "response_type": "code", "scope": "https://www.googleapis.com/auth/drive.file", "code_challenge": base64(Data(SHA256.hash(data: Data(verifier.utf8)))), "code_challenge_method": "S256", "state": expectedState, "access_type": "offline", "prompt": "consent"].map { URLQueryItem(name: $0.key, value: $0.value) }
        let code: String = try await withCheckedThrowingContinuation { cb in
            callback = cb
            timeout = Task { [weak self] in do { try await Task.sleep(for: .seconds(180)); self?.finish(.failure(AppError.message("Login habis waktu. Coba kembali."))) } catch {} }
            if !NSWorkspace.shared.open(url.url!) { finish(.failure(AppError.message("Browser tidak dapat dibuka."))) }
        }
        var fields = ["client_id": c.client_id, "code": code, "code_verifier": verifier, "redirect_uri": redirect, "grant_type": "authorization_code"]
        if let secret = c.client_secret { fields["client_secret"] = secret }
        var tokens = try await tokenRequest(fields); tokens.expiresAt = Date().addingTimeInterval(tokens.expires_in ?? 3600)
        try Vault.set("google.tokens", JSONEncoder().encode(tokens)); connected = true; status = "Google Drive terhubung."
    }
    func tokenRequest(_ fields: [String: String]) async throws -> Tokens {
        var req = URLRequest(url: URL(string: "https://oauth2.googleapis.com/token")!); req.httpMethod = "POST"
        var allowed = CharacterSet.alphanumerics; allowed.insert(charactersIn: "-._~")
        req.httpBody = Data(fields.map { $0.key.addingPercentEncoding(withAllowedCharacters: allowed)! + "=" + $0.value.addingPercentEncoding(withAllowedCharacters: allowed)! }.joined(separator: "&").utf8)
        req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        return try JSONDecoder().decode(Tokens.self, from: await checked(req))
    }
    func access() async throws -> String {
        guard let d = Vault.get("google.tokens") else { throw AppError.message("Hubungkan akun Google dahulu.") }; var t = try JSONDecoder().decode(Tokens.self, from: d)
        if (t.expiresAt ?? .distantPast) < Date().addingTimeInterval(60) {
            guard let refresh = t.refresh_token else { disconnect(); throw AppError.message("Login Google kembali diperlukan.") }
            let c = try config(); var fields = ["client_id": c.client_id, "refresh_token": refresh, "grant_type": "refresh_token"]; if let secret = c.client_secret { fields["client_secret"] = secret }
            var new = try await tokenRequest(fields); new.refresh_token = new.refresh_token ?? refresh; new.expiresAt = Date().addingTimeInterval(new.expires_in ?? 3600); try Vault.set("google.tokens", JSONEncoder().encode(new)); t = new
        }; return t.access_token
    }
    func checked(_ request: URLRequest) async throws -> Data {
        let (d, r) = try await URLSession.shared.data(for: request)
        guard let h = r as? HTTPURLResponse, (200...299).contains(h.statusCode) else { let code = (r as? HTTPURLResponse)?.statusCode ?? 0; throw AppError.message("Google merespons HTTP \(code). Periksa login, izin aplikasi, dan aktivasi Drive API.") }; return d
    }
    func upload(_ data: Data) async throws {
        let token = try await access(); let boundary = UUID().uuidString
        let name = "SakuMac-\(ISO8601DateFormatter().string(from: Date()).replacingOccurrences(of: ":", with: "-" )).json"
        let metadata = try JSONSerialization.data(withJSONObject: ["name": name, "mimeType": "application/json", "appProperties": ["application": "SakuMac"]])
        var body = Data("--\(boundary)\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n".utf8); body.append(metadata); body.append(Data("\r\n--\(boundary)\r\nContent-Type: application/json\r\n\r\n".utf8)); body.append(data); body.append(Data("\r\n--\(boundary)--\r\n".utf8))
        var request = URLRequest(url: URL(string: "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart")!); request.httpMethod = "POST"; request.httpBody = body; request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization"); request.setValue("multipart/related; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        _ = try await checked(request); status = "Backup diunggah ke Google Drive: \(name)"; UserDefaults.standard.set(Date(), forKey: "lastCloudBackup")
    }
    func list() async throws {
        let token = try await access(); var result: [DriveFile] = []; var page: String? = nil
        repeat {
            var url = URLComponents(string: "https://www.googleapis.com/drive/v3/files")!
            url.queryItems = [URLQueryItem(name: "q", value: "trashed = false and appProperties has { key='application' and value='SakuMac' }"), URLQueryItem(name: "fields", value: "nextPageToken,files(id,name,createdTime)"), URLQueryItem(name: "orderBy", value: "createdTime desc"), URLQueryItem(name: "pageSize", value: "100")]
            if let page { url.queryItems!.append(URLQueryItem(name: "pageToken", value: page)) }
            var req = URLRequest(url: url.url!); req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            let list = try JSONDecoder().decode(DriveList.self, from: await checked(req)); result += list.files; page = list.nextPageToken
        } while page != nil
        files = result; status = "\(files.count) backup ditemukan."
    }
    func download(_ file: DriveFile) async throws -> Data {
        guard !file.id.isEmpty, file.id.allSatisfy({ $0.isLetter || $0.isNumber || $0 == "_" || $0 == "-" }) else { throw AppError.message("ID berkas tidak valid.") }
        var req = URLRequest(url: URL(string: "https://www.googleapis.com/drive/v3/files/\(file.id)?alt=media")!); req.setValue("Bearer \(try await access())", forHTTPHeaderField: "Authorization"); return try await checked(req)
    }
    func run(_ operation: @escaping @MainActor () async throws -> Void) {
        guard !busy else { return }; busy = true; status = "Memproses…"
        Task { do { try await operation() } catch { status = error.localizedDescription }; busy = false }
    }
}
