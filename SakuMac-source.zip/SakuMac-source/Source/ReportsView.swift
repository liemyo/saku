import SwiftUI
import Charts

let idID = Locale(identifier: "id_ID")
func monthName(_ d: Date, short: Bool = false) -> String { let f = DateFormatter(); f.locale = idID; f.dateFormat = short ? "MMM yy" : "MMMM yyyy"; return f.string(from: d) }
func compact(_ n: Int64) -> String {
    let v = Double(n); switch abs(v) {
    case 1e9...: return String(format: "%.1f M", v / 1e9).replacingOccurrences(of: ".", with: ",")
    case 1e6...: return String(format: "%.1f jt", v / 1e6).replacingOccurrences(of: ".", with: ",")
    case 1e3...: return String(format: "%.0f rb", v / 1e3)
    default: return String(n) }
}

struct ReportsView: View {
    @EnvironmentObject var store: Store
    @AppStorage("reportMode") var mode = "Bulanan"
    @State<Date> var month = Reports.monthStart(Date())
    @State<Date> var start = Calendar.current.date(byAdding: .month, value: -5, to: Reports.monthStart(Date()))!
    @State<Date> var end = Date()
    @State<UUID?> var wallet: UUID?
    @State<String?> var selected: String?
    let cal = Calendar.current

    var bounds: (Date, Date) {
        if mode == "Bulanan" { return (month, cal.date(byAdding: .month, value: 1, to: month)!) }
        return (cal.startOfDay(for: min(start, end)), cal.date(byAdding: .day, value: 1, to: cal.startOfDay(for: max(start, end)))!)
    }
    var entries: [Entry] { let (s, e) = bounds; return store.ledger.entries.filter { $0.date >= s && $0.date < e && (wallet == nil || wallet == $0.wallet || wallet == $0.destination) } }
    var expenses: [Entry] { let (s, e) = bounds; return Reports.expenses(store.ledger, from: s, to: e, wallet: wallet) }
    var categories: [CategoryTotal] { Reports.byCategory(store.ledger, expenses) }
    /// Monthly view: the 12 months ending at the chosen month. Range view: the months inside the range.
    var monthWindow: (Date, Date) { mode == "Bulanan" ? (cal.date(byAdding: .month, value: -11, to: month)!, cal.date(byAdding: .month, value: 1, to: month)!) : (Reports.monthStart(bounds.0), bounds.1) }
    var monthEntries: [Entry] { let (s, e) = monthWindow; let es = Reports.expenses(store.ledger, from: s, to: e, wallet: wallet); return selected == nil ? es : es.filter { Reports.key($0) == selected } }
    var months: [MonthTotal] { let (s, e) = monthWindow; return Reports.byMonth(monthEntries, from: s, to: e) }
    var title: String { mode == "Bulanan" ? monthName(month) : "\(bounds.0.formatted(date: .abbreviated, time: .omitted)) – \(bounds.1.addingTimeInterval(-1).formatted(date: .abbreviated, time: .omitted))" }

    var body: some View {
        let cats = categories; let total = cats.reduce(Int64(0)) { $0 + $1.total }; let ms = months
        ScrollView { VStack(alignment: .leading, spacing: 24) {
            controls
            HStack { Metric(title: "Pemasukan", value: entries.filter { $0.kind == .income }.reduce(0) { $0 + $1.amount }, icon: "arrow.down.left"); Metric(title: "Pengeluaran", value: total, icon: "arrow.up.right", color: .red); Metric(title: "Selisih", value: entries.filter { $0.kind == .income }.reduce(0) { $0 + $1.amount } - total, icon: "chart.line.uptrend.xyaxis") }
            CategorySection(categories: cats, total: total, selected: $selected, title: title)
            MonthSection(months: ms, highlight: mode == "Bulanan" ? month : nil, category: selected.flatMap { k in cats.first { $0.key == k }?.name ?? "kategori terpilih" }, entries: monthEntries) { m in mode = "Bulanan"; month = m }
            if let k = selected { SelectedList(entries: expenses.filter { Reports.key($0) == k }.sorted { $0.date > $1.date }, name: cats.first { $0.key == k }?.name ?? "") }
            Divider()
            HStack {
                Button("Ekspor ringkasan CSV") { do { try saveFile("Ringkasan-pengeluaran.csv", type: .commaSeparatedText, data: Data(Reports.summaryCSV(store.ledger, categories: cats, months: ms, title: "Pengeluaran \(title)").utf8)) } catch { store.message = error.localizedDescription } }
                Button("Ekspor transaksi CSV") { do { try saveFile("Laporan-SakuMac.csv", type: .commaSeparatedText, data: Data(CSV.export(store.ledger, entries: entries).utf8)) } catch { store.message = error.localizedDescription } }
                Button("Ekspor PDF") { do { try saveFile("Laporan-SakuMac.pdf", type: .pdf, data: PDFReport.make(store.ledger, entries: entries, start: bounds.0, end: bounds.1.addingTimeInterval(-1))) } catch { store.message = error.localizedDescription } }
                Spacer(); Text("\(entries.count) transaksi").foregroundStyle(.secondary)
            }
        }.padding(28) }.onChange(of: wallet) { _, _ in selected = nil }
    }

    var controls: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 14) {
                Picker("", selection: $mode) { Text("Bulanan").tag("Bulanan"); Text("Rentang waktu").tag("Rentang") }.pickerStyle(.segmented).frame(width: 240).labelsHidden()
                Spacer()
                Picker("Dompet", selection: $wallet) { Text("Semua dompet").tag(nil as UUID?); ForEach(store.ledger.wallets) { Text($0.name).tag(Optional($0.id)) } }.frame(width: 230)
            }
            if mode == "Bulanan" {
                HStack(spacing: 10) {
                    Button { month = cal.date(byAdding: .month, value: -1, to: month)! } label: { Image(systemName: "chevron.left") }
                    Text(monthName(month)).font(.title3.bold()).frame(minWidth: 170)
                    Button { month = cal.date(byAdding: .month, value: 1, to: month)! } label: { Image(systemName: "chevron.right") }.disabled(month >= Reports.monthStart(Date()))
                    Button("Bulan ini") { month = Reports.monthStart(Date()) }
                }
            } else {
                HStack(spacing: 10) {
                    DatePicker("Dari", selection: $start, displayedComponents: .date).frame(width: 200)
                    DatePicker("Sampai", selection: $end, displayedComponents: .date).frame(width: 210)
                    Menu("Cepat") {
                        Button("3 bulan terakhir") { preset(3) }; Button("6 bulan terakhir") { preset(6) }; Button("12 bulan terakhir") { preset(12) }
                        Button("Tahun ini") { start = cal.date(from: cal.dateComponents([.year], from: Date()))!; end = Date() }
                        Button("Tahun lalu") { let y = cal.date(byAdding: .year, value: -1, to: cal.date(from: cal.dateComponents([.year], from: Date()))!)!; start = y; end = cal.date(byAdding: .day, value: -1, to: cal.date(byAdding: .year, value: 1, to: y)!)! }
                        Button("Semua data") { start = store.ledger.entries.map(\.date).min() ?? Date(); end = Date() }
                    }.frame(width: 90)
                }
            }
        }
    }
    func preset(_ n: Int) { start = cal.date(byAdding: .month, value: -(n - 1), to: Reports.monthStart(Date()))!; end = Date() }
}

let palette: [Color] = [Color(red: 0.16, green: 0.55, blue: 0.43), Color(red: 0.27, green: 0.49, blue: 0.85), Color(red: 0.91, green: 0.58, blue: 0.20), Color(red: 0.62, green: 0.40, blue: 0.80), Color(red: 0.86, green: 0.36, blue: 0.40), Color(red: 0.25, green: 0.70, blue: 0.75), Color.gray]
struct CategorySection: View {
    var categories: [CategoryTotal]; var total: Int64; @Binding var selected: String?; var title: String
    func color(_ i: Int) -> Color { categories.count > 7 ? palette[min(i, 6)] : palette[i % palette.count] }
    var slices: [CategoryTotal] {
        guard categories.count > 7 else { return categories }
        let rest = categories.dropFirst(6); return Array(categories.prefix(6)) + [CategoryTotal(key: "_rest", name: "Lainnya (\(rest.count))", total: rest.reduce(0) { $0 + $1.total }, count: rest.reduce(0) { $0 + $1.count })]
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack { Text("Pengeluaran per kategori").font(.title3.bold()); Text(title).foregroundStyle(.secondary); Spacer(); if selected != nil { Button("Tampilkan semua kategori") { selected = nil } } }
            if categories.isEmpty { Text("Belum ada pengeluaran pada periode ini.").foregroundStyle(.secondary) }
            else {
                HStack(alignment: .top, spacing: 28) {
                    Chart(slices) { c in
                        SectorMark(angle: .value("Total", Double(c.total)), innerRadius: .ratio(0.62), angularInset: 1.2).cornerRadius(3)
                            .foregroundStyle(by: .value("Kategori", c.name)).opacity(selected == nil || selected == c.key ? 1 : 0.3)
                    }.chartForegroundStyleScale(domain: slices.map(\.name), range: slices.indices.map { color($0) }).chartLegend(.hidden).frame(width: 220, height: 220)
                    .overlay { VStack(spacing: 2) { Text("Total").font(.caption).foregroundStyle(.secondary); Text(compact(total)).font(.title3.bold()) } }
                    VStack(spacing: 4) {
                        ForEach(Array(categories.enumerated()), id: \.element.id) { i, c in
                            Button { selected = selected == c.key ? nil : c.key } label: {
                                VStack(alignment: .leading, spacing: 6) {
                                    HStack { Circle().fill(color(i)).frame(width: 9, height: 9); Text(c.name).fontWeight(selected == c.key ? .bold : .regular); Text("\(c.count)×").font(.caption).foregroundStyle(.secondary); Spacer(); Text(money(c.total)).monospacedDigit(); Text(String(format: "%.1f%%", Double(c.total) / Double(max(1, total)) * 100)).foregroundStyle(.secondary).frame(width: 58, alignment: .trailing) }
                                    GeometryReader { g in RoundedRectangle(cornerRadius: 4).fill(color(i).opacity(selected == nil || selected == c.key ? 1 : 0.3)).frame(width: max(3, g.size.width * Double(c.total) / Double(max(1, categories.first?.total ?? 1)))) }.frame(height: 7)
                                }.padding(.vertical, 5).padding(.horizontal, 8).background(selected == c.key ? accent.opacity(0.1) : .clear, in: RoundedRectangle(cornerRadius: 8)).contentShape(Rectangle())
                            }.buttonStyle(.plain)
                        }
                        Text("Klik kategori untuk melihat tren bulanannya dan daftar transaksinya.").font(.caption).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading).padding(.top, 4)
                    }
                }
            }
        }.padding(20).background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 14))
    }
}

struct MonthSection: View {
    @EnvironmentObject var store: Store
    var months: [MonthTotal]; var highlight: Date?; var category: String?; var entries: [Entry]; var pick: (Date) -> Void
    var body: some View {
        let active = months.filter { $0.total > 0 }; let avg = active.isEmpty ? 0 : active.reduce(Int64(0)) { $0 + $1.total } / Int64(active.count)
        VStack(alignment: .leading, spacing: 16) {
            HStack { Text("Pengeluaran per bulan").font(.title3.bold()); if let category { Text("· \(category)").foregroundStyle(accent).fontWeight(.semibold) }; Spacer(); Text("Rata-rata \(money(avg))/bulan").foregroundStyle(.secondary) }
            if months.allSatisfy({ $0.total == 0 }) { Text("Belum ada pengeluaran pada bulan-bulan ini.").foregroundStyle(.secondary) }
            else {
                Chart {
                    ForEach(months) { m in
                        BarMark(x: .value("Bulan", m.month, unit: .month), y: .value("Pengeluaran", Double(m.total)))
                            .foregroundStyle(highlight == m.month ? Color.red : accent.opacity(0.75)).cornerRadius(3)
                    }
                    if avg > 0 { RuleMark(y: .value("Rata-rata", Double(avg))).lineStyle(StrokeStyle(lineWidth: 1, dash: [4, 3])).foregroundStyle(.secondary) }
                }
                .chartYAxis { AxisMarks { v in AxisGridLine(); AxisValueLabel { if let d = v.as(Double.self) { Text(compact(Int64(d))) } } } }
                .chartXAxis { AxisMarks(values: .stride(by: .month, count: max(1, months.count / 12))) { v in AxisValueLabel { if let d = v.as(Date.self) { Text(monthName(d, short: true)) } } } }
                .frame(height: 230)
                VStack(spacing: 0) {
                    HStack { Text("Bulan").frame(width: 150, alignment: .leading); Text("Pengeluaran").frame(width: 150, alignment: .trailing); Text("Transaksi").frame(width: 80, alignment: .trailing); Text("vs bulan lalu").frame(width: 110, alignment: .trailing); Text("Kategori terbesar").frame(maxWidth: .infinity, alignment: .leading).padding(.leading, 20) }.font(.caption.bold()).foregroundStyle(.secondary).padding(.vertical, 6)
                    Divider()
                    ForEach(Array(months.enumerated().reversed()), id: \.element.id) { i, m in
                        let prev = i > 0 ? months[i - 1].total : 0
                        let top = Reports.byCategory(store.ledger, entries.filter { Reports.monthStart($0.date) == m.month }).first
                        Button { pick(m.month) } label: {
                            HStack {
                                Text(monthName(m.month)).frame(width: 150, alignment: .leading).fontWeight(highlight == m.month ? .bold : .regular)
                                Text(money(m.total)).monospacedDigit().frame(width: 150, alignment: .trailing)
                                Text("\(m.count)").foregroundStyle(.secondary).frame(width: 80, alignment: .trailing)
                                Group { if prev > 0 { let pct = (Double(m.total) - Double(prev)) / Double(prev) * 100; Text(String(format: "%@%.0f%%", pct > 0 ? "▲ " : pct < 0 ? "▼ " : "", abs(pct))).foregroundStyle(pct > 0 ? .red : accent) } else { Text("—").foregroundStyle(.secondary) } }.frame(width: 110, alignment: .trailing)
                                Text(top.map { "\($0.name) · \(compact($0.total))" } ?? "—").foregroundStyle(.secondary).lineLimit(1).frame(maxWidth: .infinity, alignment: .leading).padding(.leading, 20)
                            }.padding(.vertical, 7).background(highlight == m.month ? Color.red.opacity(0.08) : .clear).contentShape(Rectangle())
                        }.buttonStyle(.plain)
                        Divider()
                    }
                }
                Text("Klik baris bulan untuk membuka laporan bulan tersebut.").font(.caption).foregroundStyle(.secondary)
            }
        }.padding(20).background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 14))
    }
}

struct SelectedList: View {
    var entries: [Entry]; var name: String
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Transaksi \(name) (\(entries.count))").font(.title3.bold())
            ForEach(entries.prefix(200)) { e in
                HStack { Text(e.date.formatted(date: .abbreviated, time: .omitted)).foregroundStyle(.secondary).frame(width: 120, alignment: .leading); Text(e.note.isEmpty ? "—" : e.note).lineLimit(1); Spacer(); Text("− " + money(e.amount)).foregroundStyle(.red).monospacedDigit() }.padding(.vertical, 3)
                Divider()
            }
            if entries.count > 200 { Text("Menampilkan 200 transaksi terbaru. Gunakan menu Transaksi untuk daftar lengkap.").font(.caption).foregroundStyle(.secondary) }
        }.padding(20).background(Color(nsColor: .controlBackgroundColor), in: RoundedRectangle(cornerRadius: 14))
    }
}
