import Foundation
import Security
import CryptoKit
import LocalAuthentication
import Combine

struct Vault {
    static func get(_ account: String) -> Data? {
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "id.local.SakuMac", kSecAttrAccount as String: account, kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?; guard SecItemCopyMatching(q as CFDictionary, &result) == errSecSuccess else { return nil }; return result as? Data
    }
    static func set(_ account: String, _ data: Data) throws {
        let q: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "id.local.SakuMac", kSecAttrAccount as String: account]
        let status = SecItemUpdate(q as CFDictionary, [kSecValueData as String: data] as CFDictionary)
        if status == errSecItemNotFound { var a = q; a[kSecValueData as String] = data; a[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly; guard SecItemAdd(a as CFDictionary, nil) == errSecSuccess else { throw AppError.message("Gagal menyimpan kredensial di Keychain.") } }
        else if status != errSecSuccess { throw AppError.message("Keychain tidak tersedia (\(status)).") }
    }
    static func remove(_ account: String) { SecItemDelete([kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "id.local.SakuMac", kSecAttrAccount as String: account] as CFDictionary) }
}
@MainActor final class Lock: ObservableObject {
    @Published var locked = Vault.get("pin") != nil; @Published var enabled = Vault.get("pin") != nil
    @Published var error = ""; var failures = 0; var retryAfter = Date.distantPast
    func setPIN(_ pin: String) throws {
        guard (6...12).contains(pin.count), pin.allSatisfy(\.isNumber) else { throw AppError.message("PIN harus 6–12 angka.") }
        var salt = Data(count: 32); let result = salt.withUnsafeMutableBytes { SecRandomCopyBytes(kSecRandomDefault, 32, $0.baseAddress!) }; guard result == errSecSuccess else { throw AppError.message("Gagal membuat PIN.") }
        // Store an HMAC verifier; PIN and verifier are held in macOS Keychain, never in backup.
        let hash = Data(HMAC<SHA256>.authenticationCode(for: Data(pin.utf8), using: SymmetricKey(data: salt)))
        try Vault.set("pin", salt + hash); enabled = true
    }
    func unlock(_ pin: String) {
        guard Date() >= retryAfter else { error = "Tunggu 30 detik sebelum mencoba kembali."; return }
        guard let data = Vault.get("pin"), data.count == 64 else { error = "PIN tidak tersedia di Keychain."; return }
        let hash = Data(HMAC<SHA256>.authenticationCode(for: Data(pin.utf8), using: SymmetricKey(data: data.prefix(32))))
        if hash == data.suffix(32) { locked = false; failures = 0; error = "" }
        else { failures += 1; error = "PIN salah."; if failures >= 5 { retryAfter = Date().addingTimeInterval(30); failures = 0; error = "Tunggu 30 detik sebelum mencoba kembali." } }
    }
    func biometric() async {
        let ctx = LAContext(); var e: NSError?
        guard ctx.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &e) else { error = "Touch ID tidak tersedia. Gunakan PIN."; return }
        do { if try await ctx.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: "Buka catatan keuangan SakuMac") { locked = false; error = "" } } catch { self.error = error.localizedDescription }
    }
    func disable() { Vault.remove("pin"); enabled = false; locked = false }
}
