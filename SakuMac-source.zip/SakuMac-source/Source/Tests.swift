import Foundation
@main struct Tests {
    @MainActor static func main() throws {
        var checks = 0
        func check(_ condition: @autoclosure () -> Bool, _ name: String) { precondition(condition(), name); checks += 1; print("PASS \(name)") }
        func rejects(_ name: String, _ action: () throws -> Void) { do { try action(); preconditionFailure(name) } catch { checks += 1; print("PASS \(name)") } }
        let dir = FileManager.default.temporaryDirectory.appendingPathComponent("SakuMac-test-\(UUID().uuidString)")
        defer { try? FileManager.default.removeItem(at: dir) }
        let store = Store(directory: dir)
        var l = store.ledger; let a = l.wallets[0].id; let b = l.wallets[1].id
        l.wallets[0].opening = 100000
        let date = Date(timeIntervalSince1970: 1700000000)
        let e1 = Entry(date: date, kind: .income, amount: 200000, wallet: a, category: l.categories.first { $0.income }!.id, note: "Gaji")
        let e2 = Entry(date: date, kind: .expense, amount: 25000, wallet: a, category: l.categories.first!.id, note: "Makan, \"enak\"\nbaris kedua 🍜")
        let e3 = Entry(date: date, kind: .transfer, amount: 50000, wallet: a, destination: b)
        l.entries = [e1, e2, e3]; try store.commit(l)
        check(store.ledger.balance(a) == 225000, "saldo pemasukan/pengeluaran/transfer")
        check(store.ledger.balance(b) == 50000, "transfer dompet tujuan")
        check(store.ledger.wallets.reduce(0) { $0 + store.ledger.balance($1.id) } == 275000, "transfer menjaga saldo total")
        let saved = try Data(contentsOf: store.file); let reload = Store(directory: dir)
        check(reload.ledger.entries == l.entries, "persistensi dan reload")
        let json = try encoder.encode(l); let round = try decoder.decode(Ledger.self, from: json)
        check(round.entries == l.entries && round.wallets == l.wallets, "backup lengkap round trip")
        var invalid = l; invalid.entries[0].amount = -1
        rejects("menolak nilai negatif") { try store.commit(invalid) }
        check(try! Data(contentsOf: store.file) == saved, "data asli terjaga setelah gagal simpan")
        invalid = l; invalid.wallets[0].opening = Int64.min
        rejects("menolak overflow saldo awal") { try invalid.validate() }
        invalid = l; invalid.entries[2].destination = a
        rejects("menolak transfer ke dompet sama") { try invalid.validate() }
        invalid = l; invalid.entries[1].category = l.categories.first { $0.income }!.id
        rejects("menolak kategori salah jenis") { try invalid.validate() }
        let csv = CSV.export(l, entries: l.entries)
        var empty = l; empty.entries = []
        let (imported, count) = try CSV.importing(csv, into: empty)
        check(imported.entries == l.entries && count == 3, "CSV kutipan/koma/newline/unicode round trip")
        let (_, duplicateCount) = try CSV.importing(csv, into: imported)
        check(duplicateCount == 0, "impor berulang tanpa duplikat")
        let (_, freshCount) = try CSV.importing(csv, into: Ledger())
        check(freshCount == 3, "impor CSV membuat kategori/dompet")
        rejects("CSV tak dikenal ditolak") { _ = try CSV.importing("tanggal,jumlah\n2026,10", into: l) }
        rejects("CSV terpotong ditolak") { _ = try CSV.parse("\"abc") }
        var conflict = l; conflict.entries[0].amount += 1
        rejects("ID CSV bertabrakan ditolak") { _ = try CSV.importing(csv, into: conflict) }
        l.debts.append(Debt(name: "Budi", receivable: false, amount: 100000)); try store.commit(l)
        let debt = l.debts[0].id; try store.pay(debt, amount: 40000, wallet: a)
        check(store.ledger.debts[0].remaining == 60000, "pembayaran mengurangi sisa utang")
        check(store.ledger.balance(a) == 185000, "pembayaran memperbarui saldo")
        rejects("menolak pembayaran berlebih") { try store.pay(debt, amount: 60001, wallet: a) }
        rejects("transaksi pembayaran tidak bisa dihapus langsung") { try store.delete(store.ledger.entries.last!) }
        rejects("transaksi pembayaran tidak bisa diedit langsung") { try store.upsert(store.ledger.entries.last!) }
        let backup = try encoder.encode(store.ledger); try store.restore(json)
        check(store.ledger.debts.isEmpty, "restore mengganti data lengkap")
        try store.restore(backup)
        check(store.ledger.debts[0].remaining == 60000, "restore riwayat pembayaran")
        rejects("restore rusak ditolak") { try store.restore(Data("bad".utf8)) }
        try Data("corrupt".utf8).write(to: store.file)
        let failed = Store(directory: dir)
        check(failed.loadFailed, "berkas rusak terdeteksi")
        rejects("data rusak tidak ditimpa saat edit") { try failed.commit(Ledger()) }
        check(String(data: try! Data(contentsOf: store.file), encoding: .utf8) == "corrupt", "berkas rusak tetap terjaga")
        try failed.restore(backup)
        check(!failed.loadFailed && failed.ledger.debts[0].remaining == 60000, "pemulihan dari kondisi berkas rusak")
        let precise = Entry(kind: .income, amount: 10, wallet: a, note: "Timestamp presisi")
        try failed.upsert(precise)
        let (_, duplicatePrecise) = try CSV.importing(CSV.export(failed.ledger, entries: failed.ledger.entries), into: failed.ledger)
        check(duplicatePrecise == 0, "CSV timestamp transaksi baru tidak menghasilkan konflik duplikat")
        // Sepran Excel adapter
        let sg: [[String]] = [["01 Jan 2023 - 03 Oct 2026"], ["Income", "0"], [], ["DATE","TITLE","CATEGORY","INCOME","EXPENSE","NOTE"],
            ["45413.0","Listrik","Token","","102500.0",""], ["45413.0","Makanan","Makan dan Minum","","25000.0","Cafe, \"2\""], ["45413.0","Makanan","Makan dan Minum","","25000.0","Cafe, \"2\""], ["45414.5","Gaji","Gaji","5000000.0","",""]]
        let sr = try Sepran.rows(sg)
        check(sr.count == 4 && sr[0].expense == 102500 && sr[3].income == 5000000, "Sepran membaca kolom DATE..NOTE")
        let comps = Calendar.current.dateComponents([.year, .month, .day, .hour], from: sr[3].date)
        check(comps.year == 2024 && comps.month == 5 && comps.day == 2 && comps.hour == 12, "Sepran tanggal serial Excel")
        let (s1, n1, k1) = try Sepran.importing(sr, into: Ledger())
        check(n1 == 4 && k1 == 0 && s1.wallets.contains { $0.name == "Sepran" }, "Sepran impor membuat dompet & baris identik tetap dua")
        check(s1.entries.first { $0.kind == .income }.map { e in s1.categories.first(where: { $0.id == e.category })!.income } == true, "Sepran pemasukan ke kategori pemasukan")
        let sw = s1.wallets.first { $0.name == "Sepran" }!.id
        check(s1.balance(sw) == 5000000 - 152500, "Sepran saldo dompet")
        var edited = s1; edited.entries[0].note = "diedit di SakuMac"
        let (s2, n2, k2) = try Sepran.importing(sr + [SepranRow(date: sr[0].date, title: "Baru", category: "Token", income: 0, expense: 1000, note: "")], into: edited)
        check(n2 == 1 && k2 == 4 && s2.entries[0].note == "diedit di SakuMac", "Sepran impor ulang hanya menambah baru & menjaga edit")
        rejects("Sepran tanpa header ditolak") { _ = try Sepran.rows([["a","b"]]) }
        rejects("Sepran dua nominal ditolak") { _ = try Sepran.rows([["DATE","TITLE","CATEGORY","INCOME","EXPENSE","NOTE"], ["45413","x","y","1","1",""]]) }
        if let path = ProcessInfo.processInfo.environment["SEPRAN_XLSX"] {
            let rows = try Sepran.rows(Sepran.grid(URL(fileURLWithPath: path)))
            let (real, n, _) = try Sepran.importing(rows, into: Ledger())
            print("INFO Excel Sepran nyata: \(n) transaksi, pengeluaran \(real.entries.filter { $0.kind == .expense }.reduce(0) { $0 + $1.amount }), pemasukan \(real.entries.filter { $0.kind == .income }.reduce(0) { $0 + $1.amount })")
            check(n == rows.count, "Sepran berkas nyata terbaca seluruhnya")
        }
        // Laporan kategori & bulanan
        var rl = Ledger(); let rw = rl.wallets[0].id; let food = rl.categories[0].id; let shop = rl.categories[2].id
        let cal = Calendar.current; func day(_ y: Int, _ m: Int, _ d: Int) -> Date { cal.date(from: DateComponents(year: y, month: m, day: d, hour: 10))! }
        rl.entries = [Entry(date: day(2026, 1, 5), kind: .expense, amount: 100, wallet: rw, category: food), Entry(date: day(2026, 1, 20), kind: .expense, amount: 300, wallet: rw, category: shop),
                      Entry(date: day(2026, 3, 1), kind: .expense, amount: 50, wallet: rw, category: food), Entry(date: day(2026, 3, 2), kind: .income, amount: 999, wallet: rw, category: rl.categories.first { $0.income }!.id),
                      Entry(date: day(2026, 4, 1), kind: .expense, amount: 70, wallet: rw)]
        let q1 = Reports.expenses(rl, from: day(2026, 1, 1), to: day(2026, 4, 1))
        check(q1.count == 3, "laporan hanya pengeluaran dalam rentang")
        let bc = Reports.byCategory(rl, q1)
        check(bc.map(\.total) == [300, 150] && bc[1].count == 2, "pengeluaran per kategori terurut")
        let bm = Reports.byMonth(q1, from: Reports.monthStart(day(2026, 1, 1)), to: Reports.monthStart(day(2026, 4, 1)))
        check(bm.map(\.total) == [400, 0, 50] && bm.count == 3, "pengeluaran per bulan termasuk bulan kosong")
        check(Reports.byCategory(rl, Reports.expenses(rl, from: day(2026, 4, 1), to: day(2026, 5, 1)))[0].name == "Tanpa kategori", "pengeluaran tanpa kategori")
        check(Reports.summaryCSV(rl, categories: bc, months: bm, title: "Q1").contains("2026-02,0,0"), "ringkasan CSV kategori & bulan")
        print("\(checks) checks passed")
    }
}
