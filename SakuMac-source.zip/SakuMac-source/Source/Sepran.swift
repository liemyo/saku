import Foundation
import CryptoKit

/// Reads the "Report Details → download" .xlsx produced by Sepran (iPhone/iPad, also on Apple Silicon Mac).
/// Layout: summary rows, then a header row DATE, TITLE, CATEGORY, INCOME, EXPENSE, NOTE.
struct SepranRow: Equatable { var date: Date; var title: String; var category: String; var income: Int64; var expense: Int64; var note: String }

enum Sepran {
    static let walletName = "Sepran"
    static let header = ["DATE", "TITLE", "CATEGORY", "INCOME", "EXPENSE", "NOTE"]

    // MARK: xlsx → string grid
    static func unzip(_ file: URL, _ member: String) throws -> Data? {
        let p = Process(); p.executableURL = URL(fileURLWithPath: "/usr/bin/unzip"); p.arguments = ["-p", file.path, member]
        let out = Pipe(); p.standardOutput = out; p.standardError = Pipe()
        try p.run(); let data = out.fileHandleForReading.readDataToEndOfFile(); p.waitUntilExit()
        return p.terminationStatus == 0 ? data : nil
    }
    final class SheetParser: NSObject, XMLParserDelegate {
        var shared: [String] = []; var rows: [[String]] = []
        private var row: [Int: String] = [:]; private var col = 0; private var type = ""; private var text = ""; private var inValue = false; private var sharedMode = false
        init(sharedMode: Bool) { self.sharedMode = sharedMode }
        func parser(_ parser: XMLParser, didStartElement name: String, namespaceURI: String?, qualifiedName: String?, attributes a: [String: String] = [:]) {
            switch name {
            case "si": text = ""
            case "t": inValue = true
            case "row": row = [:]
            case "c": type = a["t"] ?? "n"; text = ""; col = Sepran.column(a["r"] ?? "") ?? row.count
            case "v": inValue = true; text = ""
            default: break
            }
        }
        func parser(_ parser: XMLParser, foundCharacters s: String) { if inValue { text += s } }
        func parser(_ parser: XMLParser, didEndElement name: String, namespaceURI: String?, qualifiedName: String?) {
            switch name {
            case "t", "v": inValue = false
            case "si": shared.append(text)
            case "c": row[col] = (type == "s") ? (Int(text).flatMap { $0 < shared.count ? shared[$0] : nil } ?? "") : text
            case "row": let n = (row.keys.max() ?? -1) + 1; rows.append((0..<n).map { row[$0] ?? "" })
            default: break
            }
        }
    }
    static func column(_ ref: String) -> Int? { var n = 0; var any = false; for ch in ref.uppercased() { guard let a = ch.asciiValue, a >= 65, a <= 90 else { break }; n = n * 26 + Int(a - 64); any = true }; return any ? n - 1 : nil }
    static func grid(_ file: URL) throws -> [[String]] {
        guard let sheet = try unzip(file, "xl/worksheets/sheet1.xml") else { throw AppError.message("Berkas bukan Excel Sepran (.xlsx) yang valid.") }
        var shared: [String] = []
        if let s = try unzip(file, "xl/sharedStrings.xml") { let sp = SheetParser(sharedMode: true); let x = XMLParser(data: s); x.delegate = sp; guard x.parse() else { throw AppError.message("Teks Excel Sepran rusak.") }; shared = sp.shared }
        let p = SheetParser(sharedMode: false); p.shared = shared; let x = XMLParser(data: sheet); x.delegate = p
        guard x.parse() else { throw AppError.message("Lembar Excel Sepran rusak.") }; return p.rows
    }

    // MARK: grid → rows
    /// Excel serial (days since 1899-12-30) → local midnight + time fraction.
    static func date(_ s: String) -> Date? {
        guard let v = Double(s), v.isFinite, v > 0, v < 2_958_466 else { return nil }
        let days = Int(v.rounded(.down)); let seconds = Int(((v - Double(days)) * 86400).rounded())
        var cal = Calendar(identifier: .gregorian); cal.timeZone = .current
        guard let base = cal.date(from: DateComponents(year: 1899, month: 12, day: 30)), let d = cal.date(byAdding: .day, value: days, to: base) else { return nil }
        return d.addingTimeInterval(TimeInterval(seconds))
    }
    static func money(_ s: String) throws -> Int64 {
        let t = s.trimmingCharacters(in: .whitespaces); if t.isEmpty { return 0 }
        guard let v = Double(t), v.isFinite, v >= 0, v <= 1e15 else { throw AppError.message("Nominal Sepran tidak valid: \(s)") }; return Int64(v.rounded())
    }
    static func rows(_ grid: [[String]]) throws -> [SepranRow] {
        guard let h = grid.firstIndex(where: { Array($0.prefix(6)).map { $0.trimmingCharacters(in: .whitespaces).uppercased() } == header }) else { throw AppError.message("Kolom DATE/TITLE/CATEGORY/INCOME/EXPENSE/NOTE tidak ditemukan. Gunakan Excel dari Sepran → Laporan → ikon unduh.") }
        var out: [SepranRow] = []
        for (i, r0) in grid[(h + 1)...].enumerated() {
            let r = r0 + Array(repeating: "", count: max(0, 6 - r0.count))
            if r.prefix(6).allSatisfy({ $0.trimmingCharacters(in: .whitespaces).isEmpty }) { continue }
            guard let d = date(r[0]) else { throw AppError.message("Tanggal Excel Sepran baris \(h + i + 2) tidak valid.") }
            let row = SepranRow(date: d, title: r[1].trimmingCharacters(in: .whitespacesAndNewlines), category: r[2].trimmingCharacters(in: .whitespacesAndNewlines), income: try money(r[3]), expense: try money(r[4]), note: r[5].trimmingCharacters(in: .whitespacesAndNewlines))
            guard (row.income > 0) != (row.expense > 0) else { throw AppError.message("Baris \(h + i + 2) Sepran harus berisi tepat satu nominal INCOME atau EXPENSE.") }
            out.append(row)
        }
        return out
    }

    // MARK: rows → ledger
    /// Stable ID from content + occurrence number, so re-importing a newer Sepran export only adds new transactions
    /// and keeps edits made in SakuMac to previously imported ones.
    static func id(_ r: SepranRow, occurrence: Int) -> UUID {
        let day = ISO8601DateFormatter.string(from: r.date, timeZone: .current, formatOptions: [.withFullDate])
        let key = ["sepran", day, r.title, r.category, String(r.income), String(r.expense), r.note, String(occurrence)].joined(separator: "\u{1F}")
        var b = Array(SHA256.hash(data: Data(key.utf8)).prefix(16)); b[6] = (b[6] & 0x0F) | 0x50; b[8] = (b[8] & 0x3F) | 0x80
        return UUID(uuid: (b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7], b[8], b[9], b[10], b[11], b[12], b[13], b[14], b[15]))
    }
    static func note(_ r: SepranRow) -> String { r.note.isEmpty || r.note == r.title ? r.title : r.title.isEmpty ? r.note : "\(r.title) — \(r.note)" }
    static func importing(_ rows: [SepranRow], into original: Ledger) throws -> (Ledger, added: Int, skipped: Int) {
        var l = original; var added = 0; var skipped = 0; var seen: [String: Int] = [:]
        let wallet: UUID
        if let w = l.wallets.first(where: { $0.name == walletName }) { wallet = w.id } else { let w = Wallet(name: walletName); l.wallets.append(w); wallet = w.id }
        var existing = Set(l.entries.map(\.id))
        for r in rows {
            let k = "\(r.date.timeIntervalSince1970)|\(r.title)|\(r.category)|\(r.income)|\(r.expense)|\(r.note)"; let occ = seen[k, default: 0]; seen[k] = occ + 1
            let id = id(r, occurrence: occ)
            guard !existing.contains(id) else { skipped += 1; continue }
            let income = r.income > 0; let name = r.category.isEmpty ? "Lainnya" : r.category; let cat: UUID
            if let c = l.categories.first(where: { $0.name == name && $0.income == income }) { cat = c.id } else { let c = Category(name: name, income: income); l.categories.append(c); cat = c.id }
            l.entries.append(Entry(id: id, date: r.date, kind: income ? .income : .expense, amount: income ? r.income : r.expense, wallet: wallet, category: cat, note: note(r)))
            existing.insert(id); added += 1
        }
        try l.validate(); return (l, added, skipped)
    }
    static func importing(file: URL, into ledger: Ledger) throws -> (Ledger, added: Int, skipped: Int) { try importing(rows(grid(file)), into: ledger) }
}
