#!/bin/zsh
set -eu
cd "${0:A:h}"
BUILD_DIR="$PWD/.build"
mkdir -p "$BUILD_DIR" "SakuMac.app/Contents/MacOS" "SakuMac.app/Contents/Resources"
swiftc -sdk /Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk -swift-version 5 -O -target arm64-apple-macosx14.0 Source/Model.swift Source/Sepran.swift Source/Security.swift Source/GoogleDrive.swift Source/ReportsView.swift Source/App.swift -o SakuMac.app/Contents/MacOS/SakuMac
codesign --force --sign - SakuMac.app
swiftc -swift-version 5 Source/Model.swift Source/Sepran.swift Source/Tests.swift -o "$BUILD_DIR/tests"
"$BUILD_DIR/tests" > Hasil-pengujian.txt
