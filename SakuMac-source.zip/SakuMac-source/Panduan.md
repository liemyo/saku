# SakuMac 0.1 untuk Apple Silicon

Aplikasi keuangan native macOS, dibuat sebagai implementasi mandiri dengan fitur Sepran iPhone/iPad sebagai acuan. **Belum setara seluruh fitur Sepran.** Data Sepran dapat diimpor dari ekspor Excel-nya (lihat "Data dari Sepran").

## Cara memakai

1. Buka SakuMac dari Applications atau Spotlight.
2. Di **Dompet**, masukkan nama dan saldo awal sebelum transaksi pertama.
3. **Tambah transaksi** untuk pemasukan, pengeluaran, atau transfer antar-dompet. Nominal IDR berupa angka bulat tanpa titik/koma.
4. Di **Transaksi**, cari/filter catatan, edit, hapus, atau ulangi transaksi dari menu tiga titik.
5. **Kategori** untuk menambah atau mengubah kategori.
6. **Utang & piutang** untuk mencatat pokok dan jatuh tempo. Pokok bersifat catatan; catat aliran kas awal sebagai transaksi terpisah. Pembayaran dari halaman utang/piutang otomatis membuat transaksi dan memperbarui saldo. Riwayat pembayaran disimpan di backup; menu rincian pembayaran belum tersedia.
7. **Laporan**:
   - **Bulanan** (◀ ▶ untuk pindah bulan) atau **Rentang waktu** (tanggal bebas, atau menu *Cepat*: 3/6/12 bulan, tahun ini, tahun lalu, semua data). Bisa difilter per dompet.
   - **Pengeluaran per kategori**: grafik donat + daftar total, jumlah transaksi, dan persen. Klik kategori untuk melihat tren bulanannya dan daftar transaksinya.
   - **Pengeluaran per bulan**: grafik batang (mode Bulanan menampilkan 12 bulan terakhir), garis rata-rata, dan tabel per bulan dengan perubahan vs bulan lalu serta kategori terbesar. Klik baris bulan untuk membuka bulan itu.
   - Ekspor ringkasan CSV (kategori & bulan), transaksi CSV, atau PDF. Ekspor .xlsx belum tersedia.
8. **Backup & pengaturan** untuk backup JSON lengkap, pemulihan dengan pratinjau, impor CSV SakuMac, tema terang/gelap, periode laporan, serta PIN/Touch ID.

## Backup ke Gmail (email) — tanpa pengaturan Google Cloud

1. **Backup & pengaturan → Backup ke Gmail**: isi alamat Gmail, klik **Kirim backup ke Gmail**.
2. Aplikasi Mail terbuka dengan lampiran `SakuMac-backup-TANGGAL.json`; klik **Kirim**. Salinan berkas juga disimpan di folder data, subfolder `Backup email`.
3. Mail harus sudah terhubung ke akun email (Pengaturan Sistem → Akun Internet → Google).
4. Opsi pengingat mingguan menampilkan pesan bila sudah lebih dari 7 hari sejak backup email terakhir.
5. Memulihkan: unduh lampiran dari Gmail → **Pulihkan backup…**.

## Google Drive menggunakan akun Gmail

Implementasi login, refresh token, upload backup, daftar backup dan download sudah ditulis. **Belum diuji terhadap akun Google nyata**, karena konfigurasi OAuth belum tersedia. Backup otomatis dijalankan paling sering sekali sehari saat aplikasi aktif dan terbuka. Bukan sinkronisasi langsung antarperangkat.

1. Buka https://console.cloud.google.com/ dan buat/pilih proyek.
2. Aktifkan **Google Drive API**.
3. Atur OAuth consent screen (Google Auth Platform). Jika status Testing, tambahkan alamat Gmail Anda sebagai test user.
4. Buat OAuth client tipe **Desktop app**, unduh berkas JSON.
5. Di SakuMac, **Backup & pengaturan → Impor konfigurasi Google…**.
6. Klik **Hubungkan akun Google**, selesaikan login di browser.
7. Klik **Upload backup sekarang**, atau aktifkan backup harian.
8. Untuk restore, klik **Daftar backup Google Drive**, pilih **Pulihkan…**, periksa pratinjau sebelum mengganti data.

Aplikasi meminta izin `drive.file` untuk berkas yang dibuatnya. Token dan konfigurasi OAuth disimpan di macOS Keychain. Memutuskan akun menghapus token lokal; pencabutan izin Google dapat dilakukan dari https://myaccount.google.com/connections.

SakuMac tidak mengirim email melalui Gmail. Akun Google/Gmail digunakan untuk mengakses Google Drive.

## Data & keamanan

Data lokal: `~/Library/Application Support/SakuMac/ledger.json`.

Setiap perubahan menyimpan salinan sebelumnya sebagai `Before-change.json`. Salinan ini hanya satu generasi, bukan arsip semua perubahan. Berkas rusak tidak otomatis ditimpa dan dapat dipulihkan lewat backup yang valid. Impor CSV memvalidasi seluruh data sebelum menyimpan; ID sama dengan isi berbeda ditolak.

PIN mengunci antarmuka saat aplikasi masuk latar belakang. Touch ID memerlukan sensor tersedia dan sidik jari sudah didaftarkan di macOS. **Data lokal, CSV, dan backup JSON belum dienkripsi oleh aplikasi**; PIN bukan enkripsi berkas. Gunakan FileVault macOS untuk perlindungan penyimpanan. PIN dan token tidak ikut dalam backup keuangan.

Aplikasi dipasang lokal dengan tanda tangan ad-hoc, bukan notarization Apple untuk distribusi publik.

## Data dari Sepran (impor Excel)

SakuMac membaca berkas Excel dari Sepran (kolom DATE, TITLE, CATEGORY, INCOME, EXPENSE, NOTE).

1. Di Sepran: **Laporan** → pilih rentang tanggal paling awal sampai hari ini → ikon **unduh** (Excel). Berkas tersimpan di Downloads, mis. `01 Jan 2023 - 03 Oct 2026.xlsx`.
2. Di SakuMac: **Backup & pengaturan → Impor Excel Sepran…** → pilih berkas tersebut.
3. Transaksi masuk ke dompet **Sepran** dengan kategori yang sama; TITLE dan NOTE digabung menjadi catatan ("Judul — catatan").

Untuk memperbarui: ekspor ulang dari Sepran dan impor lagi. Hanya transaksi baru yang ditambahkan; transaksi yang sudah diimpor, termasuk yang sudah Anda edit di SakuMac, tidak diubah atau digandakan. Catatan:
- Ekspor Excel Sepran tidak memuat nama dompet, saldo awal, transfer, maupun utang/piutang. Atur saldo awal dompet Sepran di menu **Dompet** agar saldo sesuai.
- Jika transaksi lama diubah di Sepran setelah diimpor, impor ulang akan menambahkannya sebagai transaksi baru; hapus versi lama di SakuMac.
- Transaksi yang dihapus di SakuMac akan muncul lagi bila Excel yang sama diimpor ulang.
- Arah sebaliknya (SakuMac → Sepran) tidak didukung; Sepran tidak punya fitur impor. Backup Google Drive milik Sepran juga tidak dapat dibaca aplikasi lain.

Impor awal sudah dilakukan pada 3 Okt 2026: 1.653 transaksi, total pengeluaran Rp506.558.457 (sama dengan ringkasan Excel Sepran).

## Pengujian

`Hasil-pengujian.txt` mencatat 43 pengujian logika lokal, termasuk pembacaan Excel Sepran asli. Login Google, akses Drive nyata, dan Touch ID belum diverifikasi. Source Swift dan skrip build disertakan agar dapat dilanjutkan.

Acuan fitur:
- https://apps.apple.com/id/app/sepran-expense-manager/id1457307379
- https://sepran.id/
- https://developers.google.com/identity/protocols/oauth2/native-app
- https://developers.google.com/workspace/drive/api/guides/manage-uploads
